<!DOCTYPE html>
<html>
<head data-noxhrfix>
    <title>SCM - Clases</title>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, minimum-scale=1, initial-scale=1, user-scalable=no">    
    <style>
        @-ms-viewport { width: 100vw ; min-zoom: 100% ; zoom: 100% ; }  @viewport { width: 100vw ; min-zoom: 100% zoom: 100% ; }
        @-ms-viewport { user-zoom: fixed ; min-zoom: 100% ; }           @viewport { user-zoom: fixed ; min-zoom: 100% ; }
    </style>

     <!-- Agrego las reglas css -->
    <link href="css/jquery.mobile-1.4.5.css" rel="stylesheet">

    <!-- Agrego las reglas css -->
    <link href="css/clases.css?<?php echo time()?>" rel="stylesheet">
            
    <!-- Script de jQuery-->
    <script src="js/jquery.js"></script>
    
    <!-- Script de jQueryMobile-->
    <script src="js/jquery.mobile-1.4.5.js"></script>            

    <!-- Script de la App -->
    <script src="js/clases.js?<?php echo time()?>"></script>
    
</head>

<body>

    
    <!-- Página Principal -->
    <div data-role="page" id="pageClases">

       <!-- Encabezado --> 
       <div data-role="header">
           <a data-rel="back" class="ui-btn ui-icon-home ui-btn-icon-left" id="idHost"></a>
           <h1>JSComandas M2017</h1>
           <a href="#" class="ui-btn ui-icon-user ui-btn-icon-left" id="idUser"></a>
       </div>        
       
       <!-- Página Principal -->
       <div data-role="main" class="ui-content">
            <h2>Clases</h2>

            <!-- Inputs Ocultos para Modificar y Eliminar -->
            <input type="hidden" id="idNumSelected" >
            <input type="hidden" id="idNomSelected" >
            <input type="hidden" id="idAtiSelected" >
                       
            <!-- Tabla de Clases -->
            <table class="ui-responsive" id="tblClases" >
              <thead>
                <tr>
                  <th width="20%">Num</th>
                  <th width="60%">Nom</th>
                  <th width="20%">Atiende</th>                    
                </tr>                  
              </thead>
              <tbody>
                  <tr></tr>
              </tbody>
            </table>
       </div>                    
        
       <!-- Pie de Página --> 
       <div data-role="footer" data-position="fixed">
         <h1>Operaciones</h1>
           
           <!-- Insertar --> 
           <a id="idInsertar" 
              class="ui-btn ui-corner-all ui-shadow ui-icon-plus ui-btn-icon-left">Insertar</a>
           
           <!-- Eliminar --> 
           <a id="idModificar" 
              class="ui-btn ui-corner-all ui-shadow ui-icon-edit ui-btn-icon-left">Modificar</a>
           
           <a id="idEliminar"
              class="ui-btn ui-corner-all ui-shadow ui-icon-delete ui-btn-icon-left">Eliminar</a>
       </div>
    
        <!-- Dialogo para Mensajes -->
        <div data-role="popup" id="popupDialog" data-overlay-theme="b" data-theme="b" 
             data-dismissible="false" style="max-width:400px;">
             <div data-role="header" data-theme="a">
                <h1>JSComandas M2017</h1>
             </div>
             <div role="main" class="ui-content">
                <h3 id="idMensaje" class="ui-title" >Debe Seleccionar un Registro a <span id="idOperacion"></span></h3>
                <a href="#" class="ui-btn ui-corner-all ui-shadow ui-btn-inline ui-btn-b" data-rel="back">Aceptar</a>
             </div>
        </div>
    <!-- Dialogo para Mensajes -->
    

    </div>
    <!-- Página Principal -->
    
    <!-- Página AC Clases -->    
    <div data-role="page" id="pageAbcClases">    
        
        <!-- Encabezado --> 
        <div data-role="header">
           <a data-rel="back" class="ui-btn ui-icon-back ui-btn-icon-left">Regresar</a>
           <h1>JSComandas M2017/h1>
           <a href="#" class="ui-btn ui-icon-user ui-btn-icon-left" id="idUser2"></a>
        </div>
        
        <div data-role="main" class="ui-content">
        <h2>Clases: <strong id="idAC"></strong> </h2>

            <label for="idNum">Numero:</label>
            <input type="text" id="idNum" value="Automatico" disabled>
            
            <label for="idNom">Nombre:</label>
            <input type="text" id="idNom" maxlength="10" placeholder="Captura Nombre ..." required>
            <label for="idAti">Atiende:</label>
            <select id="idAti">
                <option value="Cocina">Cocina</option>
                <option value="Barra">Barra</option>
            </select>
            <br>
            <div class="Mensajes">
                <strong>Mensaje: </strong><span id="idResultado">Ready</span>
            </div>
            <button class="ui-btn" id="idAceptar">Aceptar</button>
            
        </div>            

        <!-- Pie de Página --> 
        <div data-role="footer" data-position="fixed">
          <h1>Capture el Nombre de la Clase y quien Atiende</h1>
        </div>
        
    </div>
    <!-- Página AC Clases -->

    
</body>
</html>

