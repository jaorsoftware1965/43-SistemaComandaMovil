<!DOCTYPE html>
<html>
<head>
    <title>SCM - Entregas</title>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, minimum-scale=1, initial-scale=1, user-scalable=no">    
    <style>
        @-ms-viewport { width: 100vw ; min-zoom: 100% ; zoom: 100% ; }  @viewport { width: 100vw ; min-zoom: 100% zoom: 100% ; }
        @-ms-viewport { user-zoom: fixed ; min-zoom: 100% ; }           @viewport { user-zoom: fixed ; min-zoom: 100% ; }
    </style>

    <!-- Agrego las reglas css -->
    <link href="css/entregas.css" rel="stylesheet">
    
    <!-- Agrego las reglas css -->
    <link href="css/themes/default/jquery.mobile-1.4.5.min.css" rel="stylesheet">
            
    <!-- Script de jQuery-->
    <script src="js/jquery.js"></script>
    
    <!-- Script de jQueryMobile-->
    <script src="js/jquery.mobile-1.4.5.js"></script>            

    <!-- Script de la App -->
    <script src="js/entregas.js"></script>
    
</head>

<body>

    
    <!-- Página Principal -->
    <div data-role="page" id="pageEntregas">

       <!-- Encabezado --> 
       <div data-role="header">
           <a data-rel="back" class="ui-btn ui-icon-home ui-btn-icon-left" >Home</a>
           <h1>SCM 2017</h1>
           <a href="#" class="ui-btn ui-icon-user ui-btn-icon-left" id="idUser"></a>
       </div>        
       
       <!-- Página Principal -->
       <div data-role="main" class="ui-content">
            <h2>Entregas</h2>
            
            <!-- Tabla de Productos a Entregar -->
            <table data-role="table" class="ui-responsive" id="tblEntregas" >
              <thead>
                <tr>
                   <th width="10%">Serv</th>
                   <th width="10%">Mesa</th>
                   <th width="10%">Reg</th>
                   <th width="35%">Producto</th>
                   <th width="35%">Comentario</th>    
                </tr>                  
              </thead>
              <tbody>
                  <tr></tr>
              </tbody>
            </table>
       </div>                    
        
       <!-- Pie de Página --> 
       <div data-role="footer" data-position="fixed">
         <h1>Seleccione el Producto cuando ya lo vaya a Entregar</h1>           
       </div>        
    </div>
    <!-- Página Principal -->
        
</body>
</html>