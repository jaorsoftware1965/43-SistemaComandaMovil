<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");


// Variables para acceso
$sUsuarioIde="IdeDemo";
$sUsuarioCve="CveDemo";
$sUsuarioNom="NomDemo";
$sUsuarioTip="TipDemo";

// Obtiene Usuario y Clave del POST
//echo "Obteniendo parámetros de Acceso ...<br>";

if (isset($_POST['UsuarioIde']))
   $sUsuarioIde = $_POST['UsuarioIde'];

if (isset($_POST['UsuarioCve']))
   $sUsuarioCve = $_POST['UsuarioCve'];

if (isset($_POST['UsuarioNom']))
   $sUsuarioNom = $_POST['UsuarioNom'];

if (isset($_POST['UsuarioTip']))
   $sUsuarioTip = $_POST['UsuarioTip'];

// Preparamos el Query de Inserción a Usuarios
$Query  = " INSERT INTO Usuarios (UsuarioIde,UsuarioCve,UsuarioNom,UsuarioTip) ";
$Query .= " VALUES ('".$sUsuarioIde."','".$sUsuarioCve."','".$sUsuarioNom."','".$sUsuarioTip."')";


// Ejecuta Query y obtiene Registros
//echo "Ejecutando Inserción de Acceso ...<br>";
$Registros = $conexion->query($Query);

if (!$Registros)
{   
    // Devuelve el Error encontrado 
    die ("Error en Inserción :".$conexion->error);
}   
else
{
    echo "Se ha Insertado el Usuario";
}
