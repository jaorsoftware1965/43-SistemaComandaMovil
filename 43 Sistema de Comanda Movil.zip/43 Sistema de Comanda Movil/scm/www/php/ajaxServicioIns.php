<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");


// Variables para Inserción
$sMesaNum="";
$sMeseroIde="";
$sComensalesNum="";


if (isset($_POST['MesaNum']))
   $sMesaNum = $_POST['MesaNum'];

if (isset($_POST['MeseroIde']))
   $sMeseroIde = $_POST['MeseroIde'];

if (isset($_POST['ComensalesNum']))
   $sComensalesNum = $_POST['ComensalesNum'];

// Se inicia transacción
$conexion->autocommit(FALSE);

// Preparamos el Query de Inserción a Usuarios
$Query  = " INSERT INTO Servicios (MesaNum, MeseroIde, ComensalesNum) ";
$Query .= " VALUES (".$sMesaNum.",'".$sMeseroIde."',".$sComensalesNum.")";


// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

if (!$Registros)
{        
    $conexion->rollback();
    die ("Error en Inserción del Servicio :".$conexion->connect_error);
}   
else
{
    // Preparando Query para Status de la Mesa
    $Query  = " UPDATE Mesas Set ";
    $Query .= " MeseroIde ='".$sMeseroIde."'";
    $Query .= " WHERE MesaNum =".$sMesaNum;

    // Ejecuta Query y obtiene Registros
    $Registros = $conexion->query($Query);

    if (!$Registros)
	{        
		$conexion->rollback();
		die ("Error al Actualizar Status Mesa :".$conexion->connect_error);
	}   
	else
	{

	    // Confirma transacción
	    if (!$conexion->commit()) 
	        echo "Error en Commit Transacction";
	    else
 	       echo "Se ha insertado el Servicio";
    }
}
