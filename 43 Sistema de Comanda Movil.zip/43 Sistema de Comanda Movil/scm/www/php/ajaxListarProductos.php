<?php
header('Access-Control-Allow-Origin: *');

// Datos de Conexion
require ("conexion.php");

// Variable para filtrar Productos por Clase
$sClaseNum="";


if (isset($_POST['ClaseNum']))
   $sClaseNum = $_POST['ClaseNum'];

// Preparamos el Query de Consulta a Usuarios
$Query  = " SELECT ProductoIde, ProductoNom, ProductoPre, ClaseNom, Productos.ClaseNum As ClaseNum";
$Query .= " FROM   Productos, Clases ";
$Query .= " WHERE  Productos.ClaseNum = Clases.ClaseNum ";
if ($sClaseNum!="")
   $Query .= " AND  Productos.ClaseNum = ".$sClaseNum;
$Query .= " ORDER  BY ClaseNom,ProductoIde";


// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

if (!$Registros)
{    
    die ("Error en Consulta :<br>".$conexion->connect_error);
}   

// Verifica si hubo resultados
if ($Registros->num_rows<=0)
{
    $result="";
}
else
{    
    // Ciclo para obtener
    while ($row = $Registros->fetch_assoc())
    {        
        $result[] = array('ide' => $row['ProductoIde'],'nom' => $row['ProductoNom'],'pre' => $row['ProductoPre'],'cla' => $row['ClaseNom'],'cve' => $row['ClaseNum'],);
    }    
}   
echo json_encode($result);
    


