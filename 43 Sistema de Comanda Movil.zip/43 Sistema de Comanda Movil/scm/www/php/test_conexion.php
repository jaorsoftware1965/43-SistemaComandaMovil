<?php

// Incluye el archivo de Conexion
echo "Cargando archivo de configuracion ...<br>";
require("config.php");

// Se crea la conexion
echo "Crea conexion ...<br>";
$conexion = new mysqli($servidor,$usuario,$password,$basedatos);

// Verifica si hubo error
if ($conexion->connect_errno)
{
    // Despliega mensaje de Error
    die ("Error en Conexión :<br>".$conexion->connect_error);
}
else
{	
	echo "Accediendo a Base de Datos ...<br>";
}

// Verifica conexion a BD
if (!$conexion->select_db($basedatos))
    die ("Error en Selección de Base de Datos :<br>".$conexion->error);
else
{
   echo "Ok<br>";
}
