<?php

// Incluye el archivo de Configuracion
require("config.php");

// Se crea la conexion
$conexion = new mysqli($servidor,$usuario,$password,$basedatos);

// Verifica si hubo error
if ($conexion->connect_errno)
{
    // Despliega mensaje de Error
    die ("Error en Conexión :<br>".$conexion->connect_error);
}

// Verifica conexion a BD
if (!$conexion->select_db($basedatos))
    die ("Error en Selección de Base de Datos :<br>".$conexion->error);
