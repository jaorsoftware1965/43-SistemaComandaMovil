<?php

// Datos de Conexion
$servidor="localhost";
$usuario="root";
$password="";
$basedatos="scm";
