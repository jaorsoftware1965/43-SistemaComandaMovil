<?php
header('Access-Control-Allow-Origin: *');

// Datos de Conexion
require ("conexion.php");

// Variables
$sMeseroIde="";

if (isset($_POST['MeseroIde']))
   $sMeseroIde = $_POST['MeseroIde'];
	
// Preparamos el Query de Consulta de Servicios
$Query  = " SELECT ServicioNum, DATE(ServicioFec) as Fecha, DATE_FORMAT(ServicioFec, '%T') as Hora,";
$Query .= "    	   MesaNum, MeseroIde, VentaTot, ComensalesNum, ServicioSta ";
$Query .= " FROM   Servicios";
$Query .= " WHERE  DATE(ServicioFec)=DATE(now()) ";

// Verifica si es por Mesero
if ($sMeseroIde!="")
   $Query .= " AND    MeseroIde='".$sMeseroIde."'";


// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

if (!$Registros)
{    
    die ("Error: en Consulta de Servicios ".$conexion->connect_error);
}   

// Verifica si hubo resultados
if ($Registros->num_rows<=0)
{
   $result="";
}
else
{    
    while ($row = $Registros->fetch_assoc())
    {
        $result[] = array('ser' => $row['ServicioNum'],'fec' => $row['Fecha'],'hor' => $row['Hora'],'mes' => $row['MesaNum'],'use' => $row['MeseroIde'],'vta' => $row['VentaTot'],'com' => $row['ComensalesNum'],'sta' => $row['ServicioSta'],);
    }
}

// Devuelve los resultados   
echo json_encode($result);    