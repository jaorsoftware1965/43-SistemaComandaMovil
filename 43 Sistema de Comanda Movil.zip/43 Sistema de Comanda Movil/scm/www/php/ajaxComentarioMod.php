<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");

// Variables para acceso
$sComentarioNum="";
$sComentarioDsc="";

//echo "Obteniendo parámetros de Acceso ...<br>";

if (isset($_POST['ComentarioNum']))
   $sComentarioNum = $_POST['ComentarioNum'];

if (isset($_POST['ComentarioDsc']))
   $sComentarioDsc = $_POST['ComentarioDsc'];

// Preparamos el Actualización de Mesa
$Query  = " UPDATE Comentarios SET ";
$Query .= " ComentarioDsc ='".$sComentarioDsc."' ";
$Query .= " WHERE ComentarioNum ='".$sComentarioNum."' ";


// Ejecuta Query
$Registros = $conexion->query($Query);

// Valida si hubo error en Registros
if (!$Registros)
{    
    die ("Error: Al Modificar el Comentario :".$conexion->connect_error);
}   
else
{
    // Verifica si cambio
    if (mysqli_affected_rows($conexion)==0)
       echo "Aviso: Has intentado Modificar el Comentario sin cambiar la Descripción";
    else
       echo "Exito: Has Modificado el Comentario";
}
