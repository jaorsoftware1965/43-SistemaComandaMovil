<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");


// Variables para Registro
$sProductoIde="001";
$sProductoNom="producto x";
$sProductoPre="12";
$sClaseNum="1";

// Obtiene Usuario y Clave del POST
//echo "Obteniendo parámetros de Acceso ...<br>";

if (isset($_POST['ProductoIde']))
   $sProductoIde = $_POST['ProductoIde'];

if (isset($_POST['ProductoNom']))
   $sProductoNom = $_POST['ProductoNom'];

if (isset($_POST['ProductoPre']))
   $sProductoPre = $_POST['ProductoPre'];

if (isset($_POST['ClaseNum']))
   $sClaseNum = $_POST['ClaseNum'];

// Preparamos el Query de Inserción a Usuarios
$Query  = " INSERT INTO Productos (ProductoIde, ProductoNom, ProductoPre, ClaseNum) ";
$Query .= " VALUES ('".$sProductoIde."','".$sProductoNom."',".$sProductoPre.",".$sClaseNum.")";


// Ejecuta Query y obtiene Registros
//echo "Ejecutando Inserción de Acceso ...<br>";
$Registros = $conexion->query($Query);

if (!$Registros)
{    
    die ("Error en Inserción :".$conexion->connect_error);
}   
else
{
    echo "Se ha Insertado el Producto";
}
