<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");


// Variables para Operación
$sComentarioDsc="";

if (isset($_POST['ComentarioDsc']))
   $sComentarioDsc = $_POST['ComentarioDsc'];


// Preparamos el Query de Inserción a Usuarios
$Query  = " INSERT INTO Comentarios (ComentarioDsc) ";
$Query .= " VALUES ('".$sComentarioDsc."')";


// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

if (!$Registros)
{    
    die ("Error en Inserción :".$conexion->connect_error);
}   
else
{
    echo "Se ha Insertado el Comentario";
}
