<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");


// Variables para Operación
$sMesaDsc="";

// Obtiene Usuario y Clave del POST
//echo "Obteniendo parámetros de Acceso ...<br>";

if (isset($_POST['MesaDsc']))
   $sMesaDsc = $_POST['MesaDsc'];


// Preparamos el Query de Inserción a Usuarios
$Query  = " INSERT INTO Mesas (MesaDsc) ";
$Query .= " VALUES ('".$sMesaDsc."')";


// Ejecuta Query y obtiene Registros
//echo "Ejecutando Inserción de Acceso ...<br>";
$Registros = $conexion->query($Query);

if (!$Registros)
{    
    die ("Error en Inserción :".$conexion->connect_error);
}   
else
{
    echo "Se ha Insertado la Mesa";
}
