<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");


// Variables para acceso
$sClaseNom="";
$sClaseAti="";

// Obtiene datos del POST
if (isset($_POST['ClaseNom']))
   $sClaseNom = $_POST['ClaseNom'];

if (isset($_POST['ClaseAti']))
   $sClaseAti = $_POST['ClaseAti'];

// Preparamos el Query de Inserción a Usuarios
$Query  = " INSERT INTO Clases (ClaseNom,ClaseAti) ";
$Query .= " VALUES ('".$sClaseNom."','".$sClaseAti."')";


// Ejecuta Query 
$Registros = $conexion->query($Query);

if (!$Registros)
{    
    die ("Error: en Inserción de Clase ".$conexion->error);
}   
else
{
    echo "Éxito: se ha Insertado la Clase";
}
