<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");


// Variables
$sClaseNum="";

// Obtiene del POST
if (isset($_POST['ClaseNum']))
   $sClaseNum = $_POST['ClaseNum'];

// Preparamos el Query de Inserción a Usuarios
$Query  = " DELETE FROM Clases ";
$Query .= " WHERE  ClaseNum ='".$sClaseNum."' ";

// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

// Valida si hubo error en Registros
if (!$Registros)
{    
    die ("Error: Al Eliminar la Clase :".$conexion->error);
}   
else
{
    echo "Exito: Has Eliminado la Clase";
}
