<?php
header('Access-Control-Allow-Origin: *');

// Datos de Conexion
require ("conexion.php");

// Preparamos el Query de Consulta a Usuarios
$Query  = " SELECT ClaseNum, ClaseNom, ClaseAti FROM Clases ";


// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

if (!$Registros)
{    
    die ("Error: en Consulta de Clases :".$conexion->connect_error);
}   


// Verifica si hubo resultados
if ($Registros->num_rows<=0)
{
    $result="";
}
else
{    
    // Ciclo para obtener
    while ($row = $Registros->fetch_assoc())
    {
        $result[] = array('num' => $row['ClaseNum'],'nom' => $row['ClaseNom'],'ati' => $row['ClaseAti'],);
    }
}   
echo json_encode($result);
    


