<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept"); 
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

// Incluye el archivo de Conexion
require("conexion.php");


// Variables para acceso
$sUsuarioIde="";
$sUsuarioCve="";

// Obtiene Usuario y Clave del POST
//echo "Obteniendo parámetros de Acceso ...<br>";

if (isset($_POST['UsuarioIde']))
   $sUsuarioIde = $_POST['UsuarioIde'];

if (isset($_POST['UsuarioCve']))
   $sUsuarioCve = $_POST['UsuarioCve'];


// Preparamos el Query de Consulta a Usuarios
$Query  = " SELECT * FROM usuarios ";
$Query .= " WHERE  UsuarioIde='".$sUsuarioIde."'";
$Query .= " AND    UsuarioCve='".$sUsuarioCve."'";


// Ejecuta Query y obtiene Registros
//echo "Ejecutando Consulta de Acceso ...<br>";
$Registros = $conexion->query($Query);

if (!$Registros)
{    
    die ("Error en Consulta :<br>".$conexion->connect_error);
}   

// Verifica si hubo resultados
if ($Registros->num_rows<=0)
{
    echo "Error en Usuario y Clave <br>";
}
else
{
    
    // Obtiene el Registro
    $Row = $Registros->fetch_assoc();

    $result[] = array('ide' => $Row["UsuarioIde"],'nom' => $Row["UsuarioNom"],'tip' => $Row["UsuarioTip"]);
    echo json_encode($result);
    //echo ($result);
}   
