<?php
header('Access-Control-Allow-Origin: *');

// Datos de Conexion
require ("conexion.php");

// Variables
$sMeseroIde = "";

if (isset($_POST['MeseroIde']))
   $sMeseroIde = $_POST['MeseroIde'];

// Preparamos el Query de Consulta a Usuarios
$Query   = " SELECT Comandas.ServicioNum, Comandas.MesaNum, ProductoReg, ProductoNom, ProductoCom"; 
$Query  .= " FROM   Comandas,Servicios";
$Query  .= " WHERE  ProductoSta='P'";
$Query  .= " AND    Comandas.ServicioNum = Servicios.ServicioNum";
$Query  .= " AND    Comandas.MesaNum     = Servicios.MesaNum";
$Query  .= " AND    DATE (ServicioFec)   = DATE (now())";
$Query  .= " AND    MeseroIde='".$sMeseroIde."'";


// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

if (!$Registros)
{    
    die ("Error en Consulta de Entregas :".$conexion->connect_error);
}   

// Verifica si hubo resultados
if ($Registros->num_rows<=0)
    $result="";
else
{    
    // Ciclo para obtener
    while ($row = $Registros->fetch_assoc())
    {        
        $result[] = array('ser' => $row['ServicioNum'],'mes' => $row['MesaNum'],'reg' => $row['ProductoReg'],'pro' => $row['ProductoNom'],'com' => $row['ProductoCom'],);
    }    
}   
echo json_encode($result);