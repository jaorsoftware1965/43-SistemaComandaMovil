<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");

// Variables 
$sServicioNum="";

if (isset($_POST['ServicioNum']))
   $sServicioNum = $_POST['ServicioNum'];

// Preparamos el Actualización del Servicio
$Query  = " UPDATE Servicios SET ";
$Query .= " ServicioSta ='C'";
$Query .= " WHERE ServicioNum=".$sServicioNum;
echo $Query;

// Ejecuta Query
$Registros = $conexion->query($Query);

// Valida si hubo error en Registros
if (!$Registros)
{    
    die ("Error: al actualizar el Servicio ".$conexion->connect_error);
}   
else
{
    echo "Exito: has actualizado el Servicio";
}
