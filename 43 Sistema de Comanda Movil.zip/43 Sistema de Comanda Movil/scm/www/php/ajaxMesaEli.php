<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");

// Variables
$sMesaNum="";

// Obtiene Usuario y Clave del POST
//echo "Obteniendo parámetros de Acceso ...<br>";

if (isset($_POST['MesaNum']))
   $sMesaNum = $_POST['MesaNum'];

// Preparamos el Query de Inserción a Usuarios
$Query  = " DELETE FROM Mesas ";
$Query .= " WHERE  MesaNum ='".$sMesaNum."' ";

// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

// Valida si hubo error en Registros
if (!$Registros)
{    
    die ("Error: Al Eliminar la Mesa :".$conexion->connect_error);
}   
else
{
    echo "Exito: Has Eliminado la Mesa";
}
