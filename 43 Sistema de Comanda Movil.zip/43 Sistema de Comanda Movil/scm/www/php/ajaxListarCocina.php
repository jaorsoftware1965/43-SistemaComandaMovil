<?php
header('Access-Control-Allow-Origin: *');

// Datos de Conexion
require ("conexion.php");

// Preparamos el Query de Consulta a Cocina
$Query  = " SELECT ServicioNum, MesaNum, ProductoReg, ProductoNom, ProductoCom";
$Query .= " FROM   Comandas, Clases";
$Query .= " WHERE  Clases.ClaseNom= Comandas.ProductoCla";
$Query .= " AND    Clases.ClaseAti ='Cocina'";
$Query .= " AND    ProductoSta IS NULL";

// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

if (!$Registros)
{    
    die ("Error en Consulta de Cocina :".$conexion->connect_error);
}   

// Verifica si hubo resultados
if ($Registros->num_rows<=0)
    $result="";
else
{    
    // Ciclo para obtener
    while ($row = $Registros->fetch_assoc())
    {        
        $result[] = array('ser' => $row['ServicioNum'],'mes' => $row['MesaNum'],'reg' => $row['ProductoReg'],'pro' => $row['ProductoNom'],'com' => $row['ProductoCom'],);
    }
}   
echo json_encode($result);
