<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");


// Variables para acceso
$sClaseNum="";
$sClaseNom="";
$sClaseAti="";

// Obtiene del POST

if (isset($_POST['ClaseNum']))
   $sClaseNum = $_POST['ClaseNum'];

if (isset($_POST['ClaseNom']))
   $sClaseNom = $_POST['ClaseNom'];

if (isset($_POST['ClaseAti']))
   $sClaseAti = $_POST['ClaseAti'];

// Preparamos el Query de Inserción a Usuarios
$Query  = " UPDATE Clases SET ";
$Query .= " ClaseNom ='".$sClaseNom."', ";
$Query .= " ClaseAti ='".$sClaseAti."'  ";
$Query .= " WHERE ClaseNum ='".$sClaseNum."' ";


// Ejecuta Query y obtiene Registros
//echo "Ejecutando Inserción de Acceso ...<br>";
$Registros = $conexion->query($Query);

// Valida si hubo error en Registros
if (!$Registros)
{    
    die ("Error: al Modificar la Clase ".$conexion->error);
}   
else
{
    // Verifica si cambio
    if (mysqli_affected_rows($conexion)==0)
       echo "Aviso: Has intentado Modificar la Clase sin cambiar los datos";
    else
       echo "Éxito: Has Modificado la Clase";
}
