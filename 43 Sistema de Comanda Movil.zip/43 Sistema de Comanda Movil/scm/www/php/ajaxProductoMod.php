<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");


// Variables para acceso
$sProductoIde="";
$sProductoNom="";
$sProductoPre="";
$sClaseNum="";

// Obtiene Usuario y Clave del POST
//echo "Obteniendo parámetros de Acceso ...<br>";

if (isset($_POST['ProductoIde']))
   $sProductoIde = $_POST['ProductoIde'];

if (isset($_POST['ProductoNom']))
   $sProductoNom = $_POST['ProductoNom'];

if (isset($_POST['ProductoPre']))
   $sProductoPre = $_POST['ProductoPre'];

if (isset($_POST['ClaseNum']))
   $sClaseNum = $_POST['ClaseNum'];

// Preparamos el Query de Inserción a Usuarios
$Query  = " UPDATE Productos SET ";
$Query .= " ProductoNom ='".$sProductoNom."',";
$Query .= " ProductoPre ='".$sProductoPre."',";
$Query .= " ClaseNum =".$sClaseNum;

$Query .= " WHERE ProductoIde ='".$sProductoIde."' ";


// Ejecuta Query y obtiene Registros
//echo "Ejecutando Inserción de Acceso ...<br>";
$Registros = $conexion->query($Query);

// Valida si hubo error en Registros
if (!$Registros)
{    
    die ("Error: Al Modificar el Producto :".$conexion->connect_error);
}   
else
{
    // Verifica si cambio
    if (mysqli_affected_rows($conexion)==0)
       echo "Aviso: Has intentado Modificar el Producto sin cambiar los datos";
    else
       echo "Exito: Has Modificado el Producto";
}
