<?php
header('Access-Control-Allow-Origin: *');

// Datos de Conexion
require ("conexion.php");

// Variable para filtrar Productos por Clase
$sMesaNum="";


if (isset($_POST['MesaNum']))
   $sMesaNum = $_POST['MesaNum'];

// Preparamos el Query de Consulta a Usuarios
$Query  = " SELECT ProductoIde, ProductoNom, ProductoCla, ProductoPre, ProductoCom, ProductoSta";
$Query .= " FROM   Comandas,Servicios";
$Query .= " WHERE  Comandas.MesaNum=".$sMesaNum;
$Query .= " AND    Servicios.ServicioNum=Comandas.ServicioNum";
$Query .= " AND    DATE(ServicioFec)=DATE(now()) ";
$Query .= " AND    VentaTot IS NULL";


// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

if (!$Registros)
{    
    die ("Error en Consulta :<br>".$conexion->connect_error);
}   

// Verifica si hubo resultados
if ($Registros->num_rows<=0)
    echo "No hay Comandas Registradas para la Mesa";
else
{    
    // Ciclo para obtener
    while ($row = $Registros->fetch_assoc())
    {        
        $result[] = array('ide' => $row['ProductoIde'],'nom' => $row['ProductoNom'],'pre' => $row['ProductoPre'],'cla' => $row['ProductoCla'],'com' => $row['ProductoCom'],'sta' => $row['ProductoSta'],);
    }
    echo json_encode($result);
}   
    


