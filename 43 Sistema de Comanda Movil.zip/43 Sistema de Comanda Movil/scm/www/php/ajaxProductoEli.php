<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");


// Variables
$sProductoIde="";

// Obtiene Usuario y Clave del POST
//echo "Obteniendo parámetros de Acceso ...<br>";

if (isset($_POST['ProductoIde']))
   $sProductoIde = $_POST['ProductoIde'];

// Preparamos el Query de Inserción a Usuarios
$Query  = " DELETE FROM Productos ";
$Query .= " WHERE  ProductoIde ='".$sProductoIde."' ";

// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

// Valida si hubo error en Registros
if (!$Registros)
{    
    die ("Error: Al Eliminar el Producto :".$conexion->connect_error);
}   
else
{
    echo "Exito: Has Eliminado el Producto";
}
