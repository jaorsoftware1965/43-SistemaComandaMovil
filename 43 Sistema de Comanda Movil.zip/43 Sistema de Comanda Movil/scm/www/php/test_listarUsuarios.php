<?php

// Datos de Conexion
echo "Cargando conexion ...<br>";
require ("conexion.php");

// Preparamos el Query de Consulta a Usuarios
echo "Preparando Consulta de Usuarios  ...<br>";
$Query  = " SELECT * FROM usuarios ";

// Ejecuta Query y obtiene Registros
echo "Ejecutando Consulta ...<br>";
$Registros = $conexion->query($Query);

if (!$Registros)
{    
    die ("Error en Consulta :<br>".$conexion->connect_error);
}   

// Verifica si hubo resultados
if ($Registros->num_rows<=0)
    echo "No hay Usuarios Registrados";
else
{
    
    // Ciclo para obtener
    while ($Row = $Registros->fetch_assoc())
    {
        // Despliego cada dato
        echo "Num:".$Row['UsuarioNum']."<br>";
        echo "Ide:".$Row['UsuarioIde']."<br>";
        echo "Cve:".$Row['UsuarioCve']."<br>";
        echo "Nom:".$Row['UsuarioNom']."<br>";
		echo "Tip:".$Row['UsuarioTip']."<br>";
        echo "<br>";
    }
}   
    


