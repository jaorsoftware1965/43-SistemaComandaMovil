<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");


// Variables
$sUsuarioIde="";

// Obtiene Usuario y Clave del POST
//echo "Obteniendo parámetros de Acceso ...<br>";

if (isset($_POST['UsuarioIde']))
   $sUsuarioIde = $_POST['UsuarioIde'];

// Preparamos el Query de Inserción a Usuarios
$Query  = " DELETE FROM Usuarios ";
$Query .= " WHERE UsuarioIde ='".$sUsuarioIde."' ";

// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

// Valida si hubo error en Registros
if (!$Registros)
{    
    die ("Error: Al Eliminar el Usuario :".$conexion->connect_error);
}   
else
{
    echo "Exito: Has Eliminado el Usuario";
}
