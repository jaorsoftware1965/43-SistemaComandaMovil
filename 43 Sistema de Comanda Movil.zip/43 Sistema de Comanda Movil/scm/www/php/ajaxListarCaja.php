<?php
header('Access-Control-Allow-Origin: *');

// Datos de Conexion
require ("conexion.php");


// Preparamos el Query para Consultar Caja
$Query   = " SELECT ServicioNum, ServicioFec, MesaNum, MeseroIde, VentaTot ";
$Query  .= " FROM   Servicios";
$Query  .= " WHERE  DATE (ServicioFec) = DATE (now())"; 
$Query  .= " AND    NOT (VentaTot IS NULL)";
$Query  .= " AND    ServicioSta IS NULL";

// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

if (!$Registros)
{    
    die ("Error en Consulta de Entregas ".$conexion->connect_error);
}   

// Verifica si hubo resultados
if ($Registros->num_rows<=0)
    $result="";
else
{    
    // Ciclo para obtener
    while ($row = $Registros->fetch_assoc())
    {        
        $result[] = array('serv' => $row['ServicioNum'],'fech' => $row['ServicioFec'],'mesa' => $row['MesaNum'],'mese' => $row['MeseroIde'],'tota' => $row['VentaTot'],);
    }    
}   
// Devuelve los Resultados
echo json_encode($result);

