<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");


// Variables para Inserción
$sMesaNum="";
$sTotal="";

if (isset($_POST['MesaNum']))
   $sMesaNum = $_POST['MesaNum'];

if (isset($_POST['Total']))
   $sTotal = $_POST['Total'];


// Se inicia transacción
$conexion->autocommit(FALSE);

// Preparamos el Query de Inserción a Usuarios
$Query  = " UPDATE Servicios ";
$Query .= " SET    VentaTot = ".$sTotal;
$Query .= " WHERE  MesaNum = ".$sMesaNum;
$Query .= " AND    VentaTot IS NULL";
echo $Query;
// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

if (!$Registros)
{        
    $conexion->rollback();
    die ("Error: al actualizar el Servicio :".$conexion->connect_error);
}   

// Preparando Query para Status de la Mesa
$Query  = " UPDATE Mesas ";
$Query .= " SET    MeseroIde = NULL";
$Query .= " WHERE  MesaNum =".$sMesaNum;

// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

if (!$Registros)
{        
	$conexion->rollback();
	die ("Error: al Actualizar Status Mesa :".$conexion->connect_error);
}   

// Confirma transacción
if (!$conexion->commit()) 
    echo "Error: en Commit Transacction";
else
    echo "Exito: se ha finalizado el Servicio";

