<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");


// Variables para Inserción
$sServicioNum=""; // Se debe obtener de la Tabla
$sMesaNum=""; 
$sComandas="";

if (isset($_POST['MesaNum']))
   $sMesaNum = $_POST['MesaNum'];

if (isset($_POST['Comandas']))
   $sComandas = $_POST['Comandas'];

// Prepara Query para obtener el Número de Servicio
$Query  = " SELECT ServicioNum FROM Servicios";
$Query .= " WHERE  MesaNum=".$sMesaNum;
$Query .= " AND    VentaTot IS NULL";

// Ejecuta la Consulta
$Registros = $conexion->query($Query);

// Verifica si no hubo error
if (!$Registros)
{    
    die ("Error al Obtener ServicioNum :<br>".$conexion->connect_error);
}   

// Verifica si hubo resultados
if ($Registros->num_rows<=0)
{
    die ("Error al Obtener ServicioNum ");
}
    
// Obtiene el Registro
$Row = $Registros->fetch_assoc();

// Obtiene el Numero de Servicio
$sServicioNum = $Row["ServicioNum"];

// Obtiene el Consecutivo del Registro de Comandas
$Query = "SELECT Count(*) AS Consecutivo FROM Comandas WHERE ServicioNum=".$sServicioNum;

// Ejecuta la Consulta
$Registros = $conexion->query($Query);

// Verifica si no hubo error
if (!$Registros)
{    
    // Error
    die ("Error: al obtener el Consecutivo de Comandas :".$conexion->connect_error);
}   

// Lee el Registro
$Row = $Registros->fetch_assoc();

// Obtiene el Consecutivo
$iConsecutivo = $Row["Consecutivo"];

// Se inicia transacción
$conexion->autocommit(FALSE);

// Obtenemos el Arreglo de Registros de Comandas
$sArrComandas =  explode("|", $sComandas);

// Ciclo para realizar la inserción
for ($iCta = 0; $iCta < count($sArrComandas); $iCta++) 
{
    //Obtiene los elementos del Registro
    list($Cve, $Nom, $Pre, $Cla, $Com) = explode(",",$sArrComandas[$iCta]);

    // Prepara el Query para Insertar la Comanda
    $Query  = " INSERT INTO Comandas (ServicioNum, MesaNum, ProductoReg, ProductoIde, ProductoNom, ProductoCla, ProductoPre,ProductoCom) ";
    $Query .= " VALUES (".$sServicioNum.",".$sMesaNum.",".$iConsecutivo.",'".$Cve."','".$Nom."','".$Cla."',".$Pre.",'".$Com."')";

    // Ejecuta Query y obtiene Registros
    $Registros = $conexion->query($Query);

    // Verifica que todo correcto
	if (!$Registros)
	{        
        // RollBack de Transacción
		$conexion->rollback();
		die ("Error en Inserción de Comanda :".$conexion->connect_error);
	}   

    // Incrementa el Consecutivo
    $iConsecutivo++;

}

// Confirma transacción
if (!$conexion->commit()) 
    echo "Error en Commit Transacction";
else
    echo "Se han insertado las Comandas";


