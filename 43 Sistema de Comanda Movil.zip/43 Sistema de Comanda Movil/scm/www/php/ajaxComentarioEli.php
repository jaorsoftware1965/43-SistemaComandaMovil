<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");

// Variables
$sComentarioNum="";

if (isset($_POST['ComentarioNum']))
   $sComentarioNum = $_POST['ComentarioNum'];

// Preparamos el Query 
$Query  = " DELETE FROM Comentarios ";
$Query .= " WHERE  ComentarioNum ='".$sComentarioNum."' ";

// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

// Valida si hubo error en Registros
if (!$Registros)
{    
    die ("Error: Al Eliminar el Comentario :".$conexion->connect_error);
}   
else
{
    echo "Exito: Has Eliminado el Comentario";
}
