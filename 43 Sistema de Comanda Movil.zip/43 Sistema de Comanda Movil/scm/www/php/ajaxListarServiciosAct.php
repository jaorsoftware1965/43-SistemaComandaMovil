<?php
header('Access-Control-Allow-Origin: *');

// Datos de Conexion
require ("conexion.php");

// Variables
$sMeseroIde="";

if (isset($_POST['MeseroIde']))
   $sMeseroIde = $_POST['MeseroIde'];
	
// Preparamos el Query de Consulta a Usuarios
$Query  = " SELECT Servicios.MesaNum, Mesas.MesaDsc";
$Query .= " FROM   Servicios, Mesas ";
$Query .= " WHERE  Servicios.MeseroIde ='".$sMeseroIde."'";
$Query .= " AND    Servicios.MesaNum = Mesas.MesaNum";
$Query .= " AND    DATE(ServicioFec)=DATE(now()) ";
$Query .= " AND    VentaTot IS NULL";

// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

if (!$Registros)
{    
    die ("Error: en Consulta :<br>".$conexion->connect_error);
}   

// Verifica si hubo resultados
if ($Registros->num_rows<=0)
{
   $result="";
}
else
{    
    // Ciclo para obtener
    while ($row = $Registros->fetch_assoc())
    {
        $result[] = array('num' => $row['MesaNum'],'dsc' => $row['MesaDsc'],);
    }
}
// Devuelve los resultados   
echo json_encode($result);    

