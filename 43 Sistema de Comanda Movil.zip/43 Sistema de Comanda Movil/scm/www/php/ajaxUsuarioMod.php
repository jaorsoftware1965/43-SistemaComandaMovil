<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");

// Variables para acceso
$sUsuarioIde="sa";
$sUsuarioCve="admin";
$sUsuarioNom="NomDemo";
$sUsuarioTip="TipDemo";

// Obtiene Usuario y Clave del POST
//echo "Obteniendo parámetros de Acceso ...<br>";

if (isset($_POST['UsuarioIde']))
   $sUsuarioIde = $_POST['UsuarioIde'];

if (isset($_POST['UsuarioCve']))
   $sUsuarioCve = $_POST['UsuarioCve'];

if (isset($_POST['UsuarioNom']))
   $sUsuarioNom = $_POST['UsuarioNom'];

if (isset($_POST['UsuarioTip']))
   $sUsuarioTip = $_POST['UsuarioTip'];

// Preparamos el Query de Inserción a Usuarios
$Query  = " UPDATE Usuarios SET ";
$Query .= " UsuarioCve ='".$sUsuarioCve."',";
$Query .= " UsuarioNom ='".$sUsuarioNom."',";
$Query .= " UsuarioTip ='".$sUsuarioTip."' ";

$Query .= " WHERE UsuarioIde ='".$sUsuarioIde."' ";


// Ejecuta Query y obtiene Registros
//echo "Ejecutando Inserción de Acceso ...<br>";
$Registros = $conexion->query($Query);

// Valida si hubo error en Registros
if (!$Registros)
{    
    die ("Error al Modificar el Usuario :".$conexion->connect_error);
}   
else
{
    // Verifica si cambio
    if (mysqli_affected_rows($conexion)==0)
       echo "Aviso: Has intentado Modificar el Usuario sin cambiar los datos";
    else
       echo "Exito: Has Modificado el Usuario";
}
