<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");


// Variables
$sMesaNum="";

// Obtiene Usuario y Clave del POST
//echo "Obteniendo parámetros de Acceso ...<br>";

if (isset($_POST['MesaNum']))
   $sMesaNum = $_POST['MesaNum'];

// Se inicia transacción
$conexion->autocommit(FALSE);

// Preparamos el Query de Inserción a Usuarios
$Query  = " DELETE FROM Servicios ";
$Query .= " WHERE  MesaNum =".$sMesaNum;
$Query .= " AND    VentaTot IS NULL";

// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

// Valida si hubo error en Registros
if (!$Registros)
{    
    // RollBack de Transacción
	$conexion->rollback();
    die ("Error: Al Eliminar el Servicio :".$conexion->connect_error);
}   

// Preparando Query para Status de la Mesa
$Query  = " UPDATE Mesas Set ";
$Query .= " MeseroIde = NULL";
$Query .= " WHERE MesaNum =".$sMesaNum;

// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

if (!$Registros)
{        
	$conexion->rollback();
	die ("Error al Actualizar Status Mesa :".$conexion->connect_error);
}   
else
{

    // Confirma transacción
    if (!$conexion->commit()) 
        echo "Error en Commit Transacction";
    else
       echo "Se ha eliminado el Servicio";
}

