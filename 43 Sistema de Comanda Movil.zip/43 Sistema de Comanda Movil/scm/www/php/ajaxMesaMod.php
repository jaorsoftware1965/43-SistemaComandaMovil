<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");

// Variables para acceso
$sMesaNum="";
$sMesaDsc="";

//echo "Obteniendo parámetros de Acceso ...<br>";

if (isset($_POST['MesaNum']))
   $sMesaNum = $_POST['MesaNum'];

if (isset($_POST['MesaDsc']))
   $sMesaDsc = $_POST['MesaDsc'];

// Preparamos el Actualización de Mesa
$Query  = " UPDATE Mesas SET ";
$Query .= " MesaDsc ='".$sMesaDsc."' ";
$Query .= " WHERE MesaNum ='".$sMesaNum."' ";


// Ejecuta Query
$Registros = $conexion->query($Query);

// Valida si hubo error en Registros
if (!$Registros)
{    
    die ("Error: Al Modificar la Mesa :".$conexion->connect_error);
}   
else
{
    // Verifica si cambio
    if (mysqli_affected_rows($conexion)==0)
       echo "Aviso: Has intentado Modificar la Mesa sin cambiar la Descripción";
    else
       echo "Exito: Has Modificado la Mesa";
}
