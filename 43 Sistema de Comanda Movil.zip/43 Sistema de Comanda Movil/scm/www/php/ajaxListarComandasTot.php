<?php
header('Access-Control-Allow-Origin: *');

// Datos de Conexion
require ("conexion.php");

// Variables
$sMeseroIde="";

if (isset($_POST['MeseroIde']))
   $sMeseroIde = $_POST['MeseroIde'];
	
// Preparamos el Query de Consulta de Servicios
$Query  = " SELECT Comandas.ServicioNum, DATE(Servicios.ServicioFec) As Fecha, DATE_FORMAT(ServicioFec, '%T') As Hora,";
$Query .= "        Comandas.MesaNum, Comandas.ProductoReg, Comandas.ProductoIde,Comandas.ProductoNom, Comandas.ProductoSta";
$Query .= " FROM   Comandas, Servicios";
$Query .= " WHERE  Comandas.ServicioNum= Servicios.ServicioNum";
$Query .= " AND    Comandas.MesaNum    = Servicios.MesaNum";
$Query .= " AND    DATE(Servicios.ServicioFec) = DATE(now())";
$Query .= " AND    MeseroIde='".$sMeseroIde."'";

// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

if (!$Registros)
{    
    die ("Error: en Consulta de Comandas ".$conexion->connect_error);
}   

// Ciclo para obtener
$result="";
while ($row = $Registros->fetch_assoc())
{
    $result[] = array('ser' => $row['ServicioNum'],'fec' => $row['Fecha'],'hor' => $row['Hora'],'mes' => $row['MesaNum'],'reg' => $row['ProductoReg'],'ide' => $row['ProductoIde'],'nom' => $row['ProductoNom'],'sta' => $row['ProductoSta'],);
}

// Devuelve los resultados   
echo json_encode($result);    

