<?php
header('Access-Control-Allow-Origin: *');

// Incluye el archivo de Conexion
require("conexion.php");


// Variables para Inserción
$sServicioNum = ""; 
$sMesaNum     = ""; 
$sProductoReg = "";
$sProductoSta = "";

if (isset($_POST['ServicioNum']))
   $sServicioNum = $_POST['ServicioNum'];

if (isset($_POST['MesaNum']))
   $sMesaNum = $_POST['MesaNum'];

if (isset($_POST['ProductoReg']))
   $sProductoReg = $_POST['ProductoReg'];

if (isset($_POST['ProductoSta']))
   $sProductoSta = $_POST['ProductoSta'];

// Prepara Query para actualizar la Comanda
$Query  = " UPDATE Comandas ";
$Query .= " SET    ProductoSta ='".$sProductoSta."'";
$Query .= " WHERE  ServicioNum =".$sServicioNum;
$Query .= " AND    MesaNum     =".$sMesaNum;
$Query .= " AND    ProductoReg =".$sProductoReg;

echo $Query;

// Ejecuta la Actualización
$Registros = $conexion->query($Query);

// Verifica si no hubo error
if (!$Registros)
{    
    // Mensaje de Error
    die ("Error: al actualizar Status de Comanda :".$conexion->connect_error);
}   

// Mensaje de Éxito
echo "Exito: se ha actualizado el Status de la Comanda";


