<?php
header('Access-Control-Allow-Origin: *');

// Datos de Conexion
require ("conexion.php");

// Variables
$sProductoIde="";

if (isset($_POST['ProductoIde']))
   $sProductoIde = $_POST['ProductoIde'];
	
// Preparamos el Query de Consulta de Servicios
$Query  = " SELECT Servicios.ServicioNum, DATE(Servicios.ServicioFec) As Fecha, Servicios.MesaNum,";
$Query .= "        Comandas.ProductoIde, Comandas.ProductoNom, Comandas.ProductoCom";
$Query .= " FROM   Comandas,Servicios";
$Query .= " WHERE  Servicios.ServicioNum=Comandas.ServicioNum";
$Query .= " AND    DATE(ServicioFec)=DATE(now())";

// Verifica si es por Producto
if ($sProductoIde!="")
   $Query .= " AND    ProductoIde='".$sProductoIde."'";

$Query .="ORDER By Comandas.ProductoIde";

// Ejecuta Query y obtiene Registros
$Registros = $conexion->query($Query);

if (!$Registros)
{    
    die ("Error: en Consulta de Servicios ".$conexion->connect_error);
}   

// Ciclo para obtener
$result="";
while ($row = $Registros->fetch_assoc())
{
    $result[] = array('ser' => $row['ServicioNum'],'fec' => $row['Fecha'],'mes' => $row['MesaNum'],'ide' => $row['ProductoIde'],'nom' => $row['ProductoNom'],'com' => $row['ProductoCom'],);
}

// Devuelve los resultados   
echo json_encode($result);    

