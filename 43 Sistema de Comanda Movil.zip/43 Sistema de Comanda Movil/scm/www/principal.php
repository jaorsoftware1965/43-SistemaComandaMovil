<!DOCTYPE html>
<html>
<head data-noxhrfix>
    <title>SCM - Usuarios</title>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, minimum-scale=1, initial-scale=1, user-scalable=no">    
    <style>
        @-ms-viewport { width: 100vw ; min-zoom: 100% ; zoom: 100% ; }  @viewport { width: 100vw ; min-zoom: 100% zoom: 100% ; }
        @-ms-viewport { user-zoom: fixed ; min-zoom: 100% ; }           @viewport { user-zoom: fixed ; min-zoom: 100% ; }
    </style>

    <!-- Agrego las reglas css -->
    <link href="css/principal.css?<?php echo time()?>" rel="stylesheet">
    
    <!-- Agrego las reglas css -->
    <link href="css/themes/default/jquery.mobile-1.4.5.min.css" rel="stylesheet">
        
    <!-- Script de jQuery-->
    <script src="js/jquery.js"></script>

    <!-- Script de la App -->
    <script src="js/principal.js?<?php echo time()?>"></script>

    <!-- Script de jQueryMobile-->
    <script src="js/jquery.mobile-1.4.5.js"></script>                

</head>

<body>

    <!-- Página Principal -->
    <div data-role="page" id="pagePrincipal">

       <!-- Encabezado --> 
       <div data-role="header">
           <a id="idHost" class="ui-btn ui-icon-home ui-btn-icon-left" ></a>
           <h1>JSComandas M2017</h1>
           <a id="idUser" class="ui-btn ui-icon-user ui-btn-icon-left" ></a>
       </div>
        
       <!-- Contenido Principal --> 
       <div data-role="main" class="ui-content">
             <h1 class="Usuario">
                 <strong id="idTipo"></strong>               
                 <span id="idNombre"></span>
             </h1>

             <h2>Menu Principal</h2>
             <ul data-role="listview" data-inset="true" >
                 <li data-role="list-divider">ARCHIVOS</li>
                 <li><a id="opcUsuarios">Usuarios<span id="Usuarios" class="ui-li-count">00</span></a></li>
                 <li><a id="opcClases">Clases<span id="Clases" class="ui-li-count">00</span></a></li> 
                 <li><a id="opcProductos">Productos<span id="Productos" class="ui-li-count">00</span></a></li>
                 <li><a id="opcMesas">Mesas<span id="Mesas" class="ui-li-count">00</span></a></li>
                 <li><a id="opcComentarios">Comentarios<span id="Comentarios" class="ui-li-count">00</span></a></li>
             </ul>
           
             <ul data-role="listview" data-inset="true" >                 
                 <li data-role="list-divider">PROCESOS</li>
                 <li><a id="opcServicios">Servicios <span id="ServiciosAct" class="ui-li-count">00</span><br><span id="ServiciosTot" class="Contadores">00</span></a></li>
                 <li><a id="opcComandas">Comandas <span id="ComandasAct" class="ui-li-count">00</span><br><span id="ComandasTot" class="Contadores">00</span></a></li>
                 <li><a id="opcCocina">Cocina <span id="CocinaAct" class="ui-li-count">00</span><br><span id="CocinaTot" class="Contadores">00</span></a></li>
                 <li><a id="opcBarra">Barra <span id="BarraAct" class="ui-li-count">00</span><br><span id="BarraTot" class="Contadores">00</span></a></li>
                 <li><a id="opcEntregas">Entregas<span id="EntregasAct" class="ui-li-count">00</span><br><span id="EntregasTot" class="Contadores">00</span></a></li>
                 <li><a id="opcCaja">Caja<span id="CajaAct" class="ui-li-count">00</span><br><span id="CajaTot" class="Contadores">00</span></a></li>
             </ul>
           
             <ul data-role="listview" data-inset="true" >                 
                <li data-role="list-divider">CONSULTAS</li>
                <li><a id="opcVentas">Ventas</a></li>
             </ul>                      
             <div data-role="collapsible">
                 <h4>Consulta de Tablas</h4>
                  <p class="MsgSucess" id="tblOk"></p>
                  <p class="MsgFail" id="tblFail"></p>
             </div>
        
        </div>
        
       <!-- Pie de Página --> 
       <div data-role="footer" data-position="fixed">
         <h1>Seleccione la opción deseada</h1>
       </div>       
    </div>
    
    <!-- Página Principal -->    
</body>
</html>
