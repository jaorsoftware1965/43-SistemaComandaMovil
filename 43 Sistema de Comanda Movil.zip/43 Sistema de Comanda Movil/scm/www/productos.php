<!DOCTYPE html>
<html>
<head>
    <title>SCM - Productos</title>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, minimum-scale=1, initial-scale=1, user-scalable=no">    
    <style>
        @-ms-viewport { width: 100vw ; min-zoom: 100% ; zoom: 100% ; }  @viewport { width: 100vw ; min-zoom: 100% zoom: 100% ; }
        @-ms-viewport { user-zoom: fixed ; min-zoom: 100% ; }           @viewport { user-zoom: fixed ; min-zoom: 100% ; }
    </style>

    <!-- Agrego las reglas css -->
    <link href="css/themes/default/jquery.mobile-1.4.5.min.css" rel="stylesheet">
    
    <!-- Agrego las reglas css -->
    <link href="css/productos.css?<?php echo time()?>" rel="stylesheet">    
        
    <!-- Script de jQuery-->
    <script src="js/jquery.js"></script>
    
    <!-- Script de jQueryMobile-->
    <script src="js/jquery.mobile-1.4.5.js"></script>            

    <!-- Script de la App -->
    <script src="js/productos.js?<?php echo time()?>"></script>
    
</head>

<body>

    
    <!-- Página Principal -->
    <div data-role="page" id="pageProductos">

       <!-- Encabezado --> 
       <div data-role="header">
           <a data-rel="back" class="ui-btn ui-icon-home ui-btn-icon-left" id="idHost">Home</a>
           <h1>JSComandas M2017</h1>
           <a href="#" class="ui-btn ui-icon-user ui-btn-icon-left" id="idUser"></a>
       </div>        
       
       <!-- Página Principal -->
       <div data-role="main" class="ui-content">
            <h2>Productos</h2>

            <!-- Inputs Ocultos para Modificar y Eliminar -->
            <input type="hidden" id="idIdeSelected" >
            <input type="hidden" id="idNomSelected" >
            <input type="hidden" id="idPreSelected" >
            <input type="hidden" id="idClaSelected" >   
                       
            <!-- Tabla de Productos -->
            <table class="ui-responsive" id="tblProductos" >
              <thead>
                <tr>
                  <th width="20%">Ide</th>
                  <th width="40%">Nombre</th>                        
                  <th witdh="20%" id="ColPrecio">Precio</th>
                  <th width="20%">Clase</th>
                  <th style="display:none;">Clave</th>                    
                </tr>                  
              </thead>
              <tbody>
                  <tr></tr>
              </tbody>
            </table>
       </div>                    
        
       <!-- Pie de Página --> 
       <div data-role="footer" data-position="fixed">
         <h1>Operaciones</h1>           
           <!-- Insertar --> 
           <a id="idInsertar" 
              class="ui-btn ui-corner-all ui-shadow ui-icon-plus ui-btn-icon-left">Insertar</a>
           
           <!-- Eliminar --> 
           <a id="idModificar" 
              class="ui-btn ui-corner-all ui-shadow ui-icon-edit ui-btn-icon-left">Modificar</a>
           
           <a id="idEliminar"
              class="ui-btn ui-corner-all ui-shadow ui-icon-delete ui-btn-icon-left">Eliminar</a>
       </div>
    
        <!-- Dialogo para Mensajes -->
        <div data-role="popup" id="popupDialog" data-overlay-theme="b" data-theme="b" 
             data-dismissible="false" style="max-width:400px;">
             <div data-role="header" data-theme="a">
                <h1>JSComandas M2017</h1>
             </div>
             <div role="main" class="ui-content">
                <h3 id="idMensaje" class="ui-title" >Debe Seleccionar un Registro a <span id="idOperacion"></span></h3>
                <a href="#" class="ui-btn ui-corner-all ui-shadow ui-btn-inline ui-btn-b" data-rel="back">Aceptar</a>
             </div>
        </div>
    <!-- Dialogo para Mensajes -->
    

    </div>
    <!-- Página Principal -->
    
    <!-- Página AC Productos -->    
    <div data-role="page" id="pageAbcProductos">    
        
        <!-- Encabezado --> 
        <div data-role="header">
           <a data-rel="back" class="ui-btn ui-icon-back ui-btn-icon-left">Regresar</a>
           <h1>JSComandas M2017</h1>
           <a href="#" class="ui-btn ui-icon-user ui-btn-icon-left" id="idUser2"></a>
        </div>
        
        <div data-role="main" class="ui-content">
        <h2>Productos: <strong id="idAC"></strong> </h2>

            <label for="idIde">Identificación:</label>
            <input type="text" id="idIde" maxlength="5" placeholder="Captura Identificación ..." required>
            
            <label for="idNom">Nombre:</label>
            <input type="text" id="idNom" maxlength="30" placeholder="Captura Nombre ..." required>

            <label for="idPre">Precio:</label>
            <input type="text" id="idPre"  maxlength="3" onkeypress='return event.charCode >= 48 && event.charCode <= 57' placeholder="Captura Precio ..." required>
            
            <label for="idCla">Clase:</label>
            <select id="idCla">
            </select>
            
            <br>
            <div class="Mensajes">
                <strong>Mensaje: </strong><span id="idResultado">Ready</span>
            </div>
            <button class="ui-btn" id="idAceptar">Aceptar</button>
            
        </div>            

        <!-- Pie de Página --> 
        <div data-role="footer" data-position="fixed">
          <h1>Capture los datos del Producto</h1>
        </div>
        
    </div>
    <!-- Página ABC Productos -->

    
</body>
</html>

