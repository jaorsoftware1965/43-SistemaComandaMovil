$(document).ready(function()
{    
    // Carga el Nombre al cargar la Página
    var sUser  = window.location.search.substr(1);
    $("#idUser").html(sUser);    
    
    // Carga las Mesas disponibles al Cargar la Página
    $.post("http://localhost/scm/php/ajaxListarMesasLibres.php", 
         function(data) 
         {
            for (var i=0; i<data.length; i++) 
            {
                $('#idMesas').append('<option value="'+data[i].num+'">'+data[i].dsc+'</option>');
            }
            // Actualiza el Control para que muestre la opción
            $('#idMesas').trigger("change");
         }, 
         "json");
    
    // Colocamos lo Comensales
    for (var i=1; i<=10; i++) 
    {
        $('#idComensales').append('<option value="'+ i+'">'+i+'</option>');
    }
               
    // Captura el evento Click para el Botón de Aceptar
    $('#idAceptar').click(function(e) 
    {        
        // Valida que haya Seleccionado una Mesa Lire
        if ($("#idMesas option:selected" ).text()=="")     
        {
            sMensaje="Debe Seleccionar la Mesa";
            $('#idResultado').html(sMensaje);            
        }
        else
        {
            // Reliza la Inserción del Servicio
            $.post("http://localhost/scm/php/ajaxServicioIns.php",
            {'MesaNum':$('#idMesas').val(),
             'MeseroIde':$('#idUser').html(),
             'ComensalesNum':$('#idComensales').val()},
             function(data)
             {
                // Coloca los datos
                $("#idResultado").html(data);     
                if (data.indexOf("Error")<0)                        
                   window.location.href="comandas.html?"+$("#idUser").html()+"&"+$('#idMesas').val();
             });                         
        }
    });
    
    // Insertar Mesa
    $('#idInsertar').click(function(e) 
    {            
        $('#idAC').html('Insertar');
        $.mobile.changePage("#pageAbcMesas");
    });

    // Modificar Mesa
    $('#idModificar').click(function(e) 
    {
        // Verifica que haya un registro seleccionado
        if ($('#idNumSelected').val()=="")
        {
            $('#idOperacion').html("Modificar");
            $( "#popupDialog").popup( "open" );
            setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);
        }
        else
        {            
            // Coloca los datos a Modificar
            $('#idNum').val($('#idNumSelected').val());
            $('#idDsc').val($('#idDscSelected').val());
            $('#idAC').html("Modificar");
            $.mobile.changePage("#pageAbcMesas");                                     
        }        
    });

    // Eliminar Mesa
    $('#idEliminar').click(function(e) 
    {
        // Verifica que haya un registro seleccionado
        if ($('#idNumSelected').val()=="")
        {
            $('#idOperacion').html("Eliminar");
            $( "#popupDialog").popup( "open" );
            setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);   
        }
        else
        {
            // ajax para Eliminar los datos
            $.post("http://localhost/scm/php/ajaxMesaEli.php",
            {'MesaNum':$('#idNumSelected').val()},
             function(data)
             {                
                // Valida si hubo error
                if (data.indexOf("Error")<0)                        
                {
                    // Carga de Nuevo la Ventana
                    window.location.href="mesas.html?"+$("#idNombre").html();
                }
                else
                {
                    $('#idMensaje').html(data);
                    $( "#popupDialog").popup( "open" );
                }
                   
             });
        }
        
    });

    
});



//                var o = $('<option/>', { value: data[i].num })
//                .text(data[i].dsc)
//                .prop('selected', i == 0);
//                o.appendTo($select);
            // Activa el Primero
            //$("#idMesas").val($("#idMesas option:first").val());
            //$(".Disponibles option:first-child").attr("selected", true);
            //var myDDL = $('#idMesas');
            //myDDL[0].selectedIndex = 0;
