$(document).ready(function()
{    
    // Carga el Nombre al cargar la Página
    var sUser  = window.location.search.substr(1);
    $("#idUser").html(sUser);    
    
    // Carga los Usuarios al Cargar la Página
    $.post("http://localhost/scm/php/ajaxListarUsuarios.php", 
    {'UsuarioTip':'Mesero'},
    function(data) 
     {
        for (var i=0; i<data.length; i++) 
        {
            $('#selMeseros').append('<option value="'+data[i].ide+'">'+data[i].nom+'</option>');
        }
        // Dispara el Evento de Cambio para carga de Datos
        $('#selMeseros').trigger("change");
     }, 
     "json");
    
    // Carga las Mesas disponibles al Cargar la Página
    $.post("http://localhost/scm/php/ajaxListarProductos.php", 
     function(data) 
     {
        for (var i=0; i<data.length; i++) 
        {
            $('#selProductos').append('<option value="'+data[i].ide+'">'+data[i].nom+'</option>');
        }
        // Actualiza el Control para que muestre la opción
        $('#selProductos').trigger("change");
     }, 
     "json");

    
    // Recarga las Ventas en base al usuario
    $('#selMeseros').change(function() 
    {     
        // Verifica que no sea Seleccione
        if ($('#selMeseros').val()!="0")
        {            
            // Carga las Ventas
            fnCargaVentasPorUsuario();            
        }
    });
    
    // Recarga las Ventas en base al Producto
    $('#selProductos').change(function() 
    {    
        // Verifica que no sea Seleccione
        if ($('#selProductos').val()!="0")
        {            
            // Carga las Ventas
            fnCargaVentasPorProducto();            
        }
    });
    
    // Carga las Ventas
    function fnCargaVentasPorUsuario()
    {     
        // Carga los Servicios / Ventas 
        $.post("http://localhost/scm/php/ajaxListarServiciosTot.php", 
        {'MeseroIde':$("#selMeseros").val()},
         function(data) 
         {
            
            // Quita los Titulares
            $('#tblVentas thead').empty();
            
            // Añade los Titulares
            $('#tblVentas thead').append('<tr><th width="10%">Num</th><th width="30%">Fecha</th><th width="10%">Mesa</th><th width="10%">Mesero</th><th width="20%">Comensales</th><th width="20%">Total</th></tr>');
            
            // Limpia la Tabla primeramente
            $('#tblVentas tbody').empty();
          
            // Incializa el total
            var iTotal=0;
            
            // Ciclo para agregar
            for (var i=0; i<data.length; i++) 
            {
                $('#tblVentas tbody').append('<tr><td>'+ data[i].ser+'</td><td>'+ data[i].fec+'</td><td>'+data[i].mes+'</td><td>'+data[i].use+'</td><td>'+data[i].com+'</td><td>'+data[i].vta+'</td></tr>');
                
                // Incrementa el total
                iTotal=iTotal+parseInt(data[i].vta);
            }
            
            // Coloca el total
            $('#idTotal').val(iTotal);
         }, 
         "json");
    }
    
    // Carga las Ventas por Producto
    function fnCargaVentasPorProducto()
    {     
        // Carga los Servicios / Ventas por Producto
        $.post("http://localhost/scm/php/ajaxListarServiciosPro.php", 
        {'ProductoIde':$("#selProductos").val()},
         function(data) 
         {
            // Quita los Titulares
            $('#tblVentas thead').empty();
            
            // Añade los Titulares
            $('#tblVentas thead').append('<tr><th width="10%">Num</th><th width="20%">Fecha</th><th width="10%">Mesa</th><th width="30%">Producto</th><th width="30%">Comentario</th></tr>');
            
            // Limpia la Tabla primeramente
            $('#tblVentas tbody').empty();
            
            // Variable para el Total
            var iTotal = 0;
            
            // Ciclo para agregar
            for (var i=0; i<data.length; i++) 
            {
                $('#tblVentas tbody').append('<tr><td>'+ data[i].ser+'</td><td>'+ data[i].fec+'</td><td>'+data[i].mes+'</td><td>'+data[i].nom+'</td><td>'+data[i].com+'</td></tr>');
                // Incrementa el total
                iTotal++;
            }
            // Coloca el total
            $('#idTotal').val(iTotal);            
         }, 
         "json");
    }
    
});
