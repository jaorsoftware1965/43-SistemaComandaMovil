// Document Ready Inicio
$(document).ready(function()
{   
        
    // Obtiene los parámetros del URL
    var sParametros =window.location.search.substr(1);      
    
    // Obtiene la posición de la Mesa y Comensales
    var iPosMesa     = sParametros.indexOf("&");    
        
    // Obtiene el Usuario, Mesa y Comensales
    var sUser       = sParametros.substr(0,iPosMesa);    
    var sMesa       = sParametros.substr(iPosMesa+1);        
    
    // Ejecuta Ajax para cargar las Mesas Activas desde los Servicios, atendidas por el Usuario        
    $.post("http://localhost/scm/php/ajaxListarServiciosAct.php", 
         {'MeseroIde':sUser},   
         function(data) 
         {            
            for (var i=0; i<data.length; i++) 
            {
                $('#selMesas').append('<option value='+data[i].num+'>'+data[i].dsc+'</option>');
            }
            // Actualiza el Control para que muestre la opción
            if (sMesa!="")
               $("#selMesas").val(sMesa); 
            $('#selMesas').trigger("change");
         }, 
         "json");
    
    // Coloca el usuario en la pantalla
    $("#idUser").html(sUser);        
        
    // Ejecuta Ajax para cargar Clases de Productos        
    $.post("http://localhost/scm/php/ajaxListarClases.php", 
     function(data) 
     {         
        for (var i=0; i<data.length; i++) 
        {
            //'<option value=1>My option</option>'
            $('#idCla').append('<option value="'+ data[i].num+'">'+data[i].nom+'</option>'); 
        }
        $('#idCla').trigger("change");
     }, 
     "json");

    
    // Carga los Comentarios
    $.post("http://localhost/scm/php/ajaxListarComentarios.php", 
         function(data) 
         {
            for (var i=0; i<data.length; i++) 
            {
                $('#selComentarios').append('<option style="width: 400px" value="'+data[i].num+'">'+data[i].dsc+'</option>');
            }
            // Actualiza el Control para que muestre la opción
            $('#selComentarios').trigger("change");
         }, 
         "json");

    // Captura el Evento Click sobre la Tabla
    $('#tblProductos tbody').on( 'click', 'td', function () 
    {
        // Obtengo la Columna
        var col = $(this).parent().children().index($(this));
        
        // Obtiene información del Row
        var sCve =$(this).parent().find('td').eq(0).text();
        var sDsc =$(this).parent().find('td').eq(1).text();
        var sPre =$(this).parent().find('td').eq(2).text();
        var sCla =$(this).parent().find('td').eq(3).text();

        // Actualiza el Total de Productos
        var Productos = $('#Productos').html();
        Productos = parseInt(Productos)+1;
        $('#Productos').html(Productos);

        // Actualiza el Total
        var Total = $('#Total').html();
        var Total = parseInt(Total)+parseInt(sPre);
        $('#Total').html(Total);
            
        // Verifico si es la 3, desea capturar comentario
        if (col==3)
        {            
            // Coloca la Información
            $('#idCveSelected').val(sCve);
            $('#idDscSelected').val(sDsc);
            $('#idPreSelected').val(sPre);
            $('#idClaSelected').val(sCla);            

            // Abro la Ventana de Comentarios
            $( "#popupComentario").popup( "open" );                    
        }
        else
        {
            
            // Coloca desde Productos a Seleccionados
            $('#tblSeleccionados tbody').append('<tr><td>'+sCve+'</td><td>'+sDsc+'</td><td align="right">'+sPre+'</td><td>'+sCla+'</td><td>Sin Comentario</td></td></tr>');   
        }
        
    });
  
    // Captura el Evento Click sobre la Tabla
    $('#tblSeleccionados tbody').on( 'click', 'td', function () 
    {
        // Obtengo la Columna
        var col = $(this).parent().children().index($(this));
                    
        // Verifico si es la 4, desea capturar comentario
        if (col==4)
        {
            // Añade la Clase al Row
            $(this).parent().addClass('trSelected');
            
            // Abro la Ventana de Comentarios
            $( "#popupComentario").popup( "open" );                                
        }
        else
        {
            // Verifica si ya ha sido grabado
            if ($(this).parent().hasClass("trGrabados") || $(this).parent().hasClass("trEntregados"))
            {
                $('#idMensaje').html("No puedes eliminar Productos Grabados / Entregados");
                $( "#popupDialog").popup( "open" );
                setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);    
            }
            else
            {
                // Obtiene el Precio para descontarlo del Total
                var sPre =$(this).parent().find('td').eq(2).text();

                // Actualiza el Total de Productos
                var Productos = $('#Productos').html();
                Productos = parseInt(Productos)-1;
                $('#Productos').html(Productos);

                // Actualiza el Total
                var Total = $('#Total').html();
                var Total = parseInt(Total)-parseInt(sPre);
                $('#Total').html(Total);            

                // Remueve el Elemento de los Seleccionados
                $(this).parent().remove();        
            }
                        
        }
        
    });
    
    // Recarga las Comandas de la Mesa Seleccionada
    $('#selMesas').change(function() 
    {
                
        // Limpia la Tabla
        $('#tblSeleccionados tbody').empty();
        
        // Obtengo la Mesa para Obtener las Comandas
        var MesaNum = $("#selMesas option:selected").val();
        
        // Variables para sumarizar
        var Productos=0;
        var Total=0;
        
        // Coloca los totales
        $('#Productos').html(Productos);
        $('#Total').html(Total);

        // Carga los Comandas de la Mesa
        $.post("http://localhost/scm/php/ajaxListarComandasMesa.php", 
                 {'MesaNum':MesaNum},
                 function(data) 
                 {    
                     // Ciclo para colocar cada uno de los datos
                     for (var i=0; i<data.length; i++) 
                     {
                         if (data[i].sta=="E")
                         {
                             // Coloca el Dato en el Select
                             $('#tblSeleccionados tbody').append('<tr class="trEntregados"><td>'+ data[i].ide+'</td><td>'+ data[i].nom+'</td><td align="right">'+data[i].pre+'</td><td>'+data[i].cla+'</td><td>'+data[i].com+'</td></tr>');    
                         }
                         else
                         {
                             // Coloca el Dato en el Select
                             $('#tblSeleccionados tbody').append('<tr class="trGrabados"><td>'+ data[i].ide+'</td><td>'+ data[i].nom+'</td><td align="right">'+data[i].pre+'</td><td>'+data[i].cla+'</td><td>'+data[i].com+'</td></tr>');
                         }
                         
                         // Calcula los totales
                         Productos++;
                         Total=Total+parseInt(data[i].pre);
                     }
                        
                     // Coloca los totales
                     $('#Productos').html(Productos);
                     $('#Total').html(Total);
                                  
                 }, 
                 "json");

    });
    
    
    // Recarga los Productos Filtrando por Clase
    $('#idCla').change(function() 
    {
                
        // Limpia la Tabla
        $('#tblProductos tbody').empty();
        
        // Obtengo la Clase del Producto a Filtrar
        var ClaseNum = $("#idCla option:selected").val();
        
        // Carga los Productos al Cargar la Página
        $.post("http://localhost/scm/php/ajaxListarProductos.php", 
                 {'ClaseNum':ClaseNum},
                 function(data) 
                 {            
                     for (var i=0; i<data.length; i++) 
                     {
                         $('#tblProductos tbody').append('<tr><td>'+ data[i].ide+'</td><td>'+ data[i].nom+'</td><td align="right">'+data[i].pre+'</td><td>'+
                         data[i].cla+'</td></tr>');
                         
                     }
                 }, 
                 "json");

    });
    
    // Insertar Producto
    $('#btnAceptarComentario').click(function(e) 
    {
        // Obtiene el Número de Seleccionados
        var rowsSelected = $('#tblSeleccionados tbody tr.trSelected').length;
                
        // Verifica si hay Seleccionados
        if(rowsSelected>0)
        {
            // Es Update, Obtiene el Comentario
            var sCom = $("#selComentarios option:selected" ).text();
             
            // Coloca el comentario
            $('#tblSeleccionados tbody tr.trSelected').find('td').eq(4).text(sCom);
            
            // Elimina la Clase de Seleccionado
            $('#tblSeleccionados tbody tr.trSelected').removeClass('trSelected');
        }
        else
        {
            // Es Insert, obtiene los datos
            var sCve = $('#idCveSelected').val();
            var sDsc = $('#idDscSelected').val();
            var sPre = $('#idPreSelected').val();
            var sCla = $('#idClaSelected').val();
            var sCom = $("#selComentarios option:selected" ).text();


            // Agrega a la Tabla de Seleccionados
            $('#tblSeleccionados tbody').append('<tr><td>'+sCve+'</td><td>'+ sDsc+'</td><td align="right">'+sPre+'</td><td>'+sCla+'</td><td>'+sCom+'</td></tr>');
        }        
    });
                
        
    // Guardar las Comandas
    $('#btnGrabar').click(function(e) 
    {
        // Obtiene el Numero de Rows en la Tabla
        var rows= $('#tblSeleccionados tbody tr').length;        
        alert(rows);
        
        if (rows>0)
        {
            // Obtiene los Grabados
            var rowsGrabados = $('#tblSeleccionados tbody tr.trGrabados').length;
            
            // Obtiene los Entregados
            var rowsEntregados = $('#tblSeleccionados tbody tr.trEntregados').length;
            
            // Verifica si hay registros para grabar
            if (rows > rowsGrabados + rowsEntregados)
            {
                 // Inicializa la Variable para los Datos de la Tabla
                var sRowsTabla ="";
                var sIde,sDsc,sPre,sCla,sCom;
                // Obtiene referencia a cada uno de los tr del Body
                $("#tblSeleccionados tbody tr").each(function() 
                {
                    // Verifica que no esté grabado
                    if (!$(this).hasClass('trGrabados') && !$(this).hasClass('trEntregados'))
                    {
                        // Coloca la Clase de Grabados
                        $(this).addClass('trGrabados');

                        // Obtengo los datos por separado
                        sIde = $(this).find('td').eq(0).text();
                        sDsc = $(this).find('td').eq(1).text();
                        sPre = $(this).find('td').eq(2).text();
                        sCla = $(this).find('td').eq(3).text();
                        sCom = $(this).find('td').eq(4).text();

                        // Creando la variable con los registros de la tabla
                        sRowsTabla=sRowsTabla+sIde+","+sDsc+","+sPre+","+sCla+","+sCom+"|";
                    }
                });
                // elimina la ultima "coma"
                sRowsTabla = sRowsTabla.substr(0,sRowsTabla.length-1);

                // Ejecuta la inserción de las Comandas
                $.post("http://localhost/scm/php/ajaxComandasIns.php",
                {'MesaNum':$('#selMesas').val(),
                 'Comandas':sRowsTabla},
                 function(data)
                 {
                    if (data.indexOf("Error")>0)                        
                    {
                        $('#idMensaje').html(data);
                        $( "#popupDialog").popup( "open" );
                        setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);        
                    }                    
                 });   
            }
            else
            {
                // Mensaje de que no hay Registros
                $('#idMensaje').html("No hay Comandas para Grabar");
                $( "#popupDialog").popup( "open" );
                setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);        
            }
            
        }
        else
        {
            // Mensaje de que no hay Registros
            $('#idMensaje').html("No hay Comandas para Grabar");
            $( "#popupDialog").popup( "open" );
            setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);
        }
    });
    
    
    // Regresar
    $('#btnRegresar').click(function(e) 
    {
        // Obtiene los Grabados
        var rowsGrabados   = $('#tblSeleccionados tbody tr.trGrabados').length;
        
        // Obtiene los Entregados
        var rowsEntregados = $('#tblSeleccionados tbody tr.trEntregados').length;

        // Verifica que haya grabados o entregados
        if (rowsGrabados + rowsEntregados >0)
        {
            // Regresa
            window.history.back();
        }
        else
        {
           $('#idMensaje').html("Debes Grabar antes de Regresar o Cancelar");
           $( "#popupDialog").popup( "open" );
              setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);    
        }    
            
    });
    
    
    // Eliminar el Servicio
    $('#btnCancelar').click(function(e) 
    {
        // Obtiene los Entregados
        var rowsEntregados = $('#tblSeleccionados tbody tr.trEntregados').length;

        // Valida que no hayan sido entregados
        if (rowsEntregados>0)
        {
            // Mensaje de que no se puede cancelar lo entregado
            $('#idMensaje').html("No puedes cancelar comandas entregadas");
            $( "#popupDialog").popup( "open" );
            setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);        
        }
        else
        {
            // Ejecuta la inserción de las Comandas
            $.post("http://localhost/scm/php/ajaxServicioEli.php",
              {'MesaNum':$('#selMesas').val()},
              function(data)
              {
                  // Coloca los datos
                  //$("#idResultado").html(data);              
                  if (data.indexOf("Error")<0)
                  {
                      //window.location.href="iniciar.html?"+$("#idUser").html();
                      window.history.back();
                  }
                  else
                  {
                      $('#idMensaje').html(data);
                      $( "#popupDialog").popup( "open" );
                      setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);
                  }
              });    
        }
        
    });
    
    // Finalizar el Servicio
    $('#btnFinalizar').click(function(e) 
    {
        // Obtengo el Total
        var rowsGeneral = $('#tblSeleccionados tbody tr').length;
        
        // Obtengo el Row de Entregados
        var rowsEntregados = $('#tblSeleccionados tbody tr.trEntregados').length;
            
        // Valido que sea mayor que 0
        if (rowsEntregados > 0)
        {
            // Valido que todos estén entregados
            if (rowsGeneral == rowsEntregados)
            {
                // Ejecuta la inserción de las Comandas
                $.post("http://localhost/scm/php/ajaxServicioFin.php",
                  {'MesaNum':$('#selMesas').val(),
                   'Total':$('#Total').html()},
                  function(data)
                  {
                      // Verifica si hubo error
                      if (data.indexOf("Error")<0)
                      {
                          //window.location.href="iniciar.html?"+$("#idUser").html();
                          window.history.back();
                      }
                      else
                      {
                          // Despliega el Error
                          $('#idMensaje').html(data);
                          $( "#popupDialog").popup( "open" );
                          setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);
                      }
                  });        
            }
            else
            {
                // Despliega el Error
                $('#idMensaje').html("Debes Grabar y Entregar Comandas para Finalizar");
                $( "#popupDialog").popup( "open" );
                setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);                    
            }
        }
        else
        {
            // Despliega el Error
            $('#idMensaje').html("Debes Grabar y Entregar Comandas para Finalizar");
            $( "#popupDialog").popup( "open" );
            setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);
        }
    });

});
// Fin de Document Ready



























//    // Captura el Evento Click sobre la Tabla
//    $('#tblProductos tbody').on( 'click', 'tr', function () 
//    {
//        //var rows= $('#tblProductos tbody tr.trSelected').length;
//        //alert(rows);
//        // Agrega a la Tabla de Seleccionados
//            $('#tblSeleccionados tbody').append('<tr><td>'+ $(this).find('td').eq(0).text()+'</td><td>'+ $(this).find('td').eq(1).text()+'</td><td align="right">'+$(this).find('td').eq(2).text()+'</td><td>'+
//                         $(this).find('td').eq(3).text()+'</td></tr>');
//            
////        if ($(this).hasClass('trSelected') ) 
////        {
////            // Elimina la Clase del row
////            $(this).removeClass('trSelected');
////            
////            // Borra los datos seleccionados
////            $('#idCveSelected').val("");
////            $('#idDscSelected').val("");
////            $('#idPreSelected').val("");
////            $('#idClaSelected').val("");
////        }
////        else 
////        {
////            // Remueve los Seleccionados que haya
////            $('tr.trSelected').removeClass('trSelected');// Para que solo sea uno
////            // Añade la clase  Seleccionada
////            $(this).addClass('trSelected');  
////            // Coloca el Ide Seleccionado
////            $('#idCveSelected').val($(this).find('td').eq(0).text());
////            $('#idDscSelected').val($(this).find('td').eq(1).text());
////            $('#idPreSelected').val($(this).find('td').eq(2).text());
////            $('#idClaSelected').val($(this).find('td').eq(3).text());            
////        }
//    } );



// Obtengo el Numero de Rows en la tabla
//var rowsTable = $("#tblProductos > tbody > tr").length;

// Ciclo para borrar cada uno de ellos
//for (var iCta=0; iCta <= rowsTable; iCta++)
//{
//    document.getElementById("tblProductos").deleteRow(0);             
//}

//$('#tblProductos tr:last').after('<tr><td>'+ data[i].ide+'</td><td>'+ data[i].nom+'</td><td align="right">'+data[i].pre+'</td><td>'+
//data[i].cla+'</td><td style="display:none;">'+data[i].cve+'</td></tr>');


//var row = $(this).parent().parent().children().index($(this).parent());
        //alert('Row: ' + row + ', Column: ' + col);


//    // Captura el Evento Click sobre la Tabla
//    $('#tblProductos tbody').on( 'click', 'tr', function () 
//    {
//        // Coloca el Ide Seleccionado
//        $('#idCveSelected').val($(this).find('td').eq(0).text());
//        $('#idDscSelected').val($(this).find('td').eq(1).text());
//        $('#idPreSelected').val($(this).find('td').eq(2).text());
//        $('#idClaSelected').val($(this).find('td').eq(3).text());            
//    } );


// Insertar Producto
//    $('#idInsertar').click(function(e) 
//    {
//        // Obtiene el Numero de Seleccionados de la Tabla
//        var rows= $('#tblProductos tbody tr.trSelected').length;
//        //alert(rows);
//        
//        // Verifica que haya un registro seleccionado
//        //if ($('#idCveSelected').val()=="")
//        if (rows==0)
//        {
//            $('#idOperacion').html("Insertar");
//            $( "#popupDialog").popup( "open" );
//            setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);
//        }
//        else
//        {
//            // Agrega a la Tabla de Seleccionados
//            $('#tblSeleccionados tbody').append('<tr><td>'+ $('#idCveSelected').val()+'</td><td>'+ $('#idDscSelected').val()+'</td><td align="right">'+$('#idPreSelected').val()+'</td><td>'+
//                         $('#idClaSelected').val()+'</td></tr>');
//                         
//        }
//    });
//
//    // Eliminar Producto
//    $('#idEliminar').click(function(e) 
//    {
//        
//    });
//
//    // Eliminar Usuario
//    $('#idComentar').click(function(e) 
//    {
//
//    });


//    // Carga los Productos al Cargar la Página
//    $.post("http://localhost/scm/php/ajaxListarProductos.php", 
//             function(data) 
//             {
//                for (var i=0; i<data.length; i++) 
//                {
//                    $('#tblProductos tbody').append('<tr><td>'+ data[i].ide+'</td><td>'+ data[i].nom+'</td><td align="right">'+data[i].pre+'</td><td>'+
//                    data[i].cla+'</td></tr>');
//                }
//             }, 
//             "json");
//             




//    // Captura el Evento Click sobre la Tabla
//    $('#tblSeleccionados tbody').on( 'click', 'tr', function () 
//    {   
//        // Obtiene el Precio para descontarlo del Total
//        var sPre =$(this).find('td').eq(2).text();
//        
//        // Actualiza el Total de Productos
//        var Productos = $('#Productos').html();
//        Productos = parseInt(Productos)-1;
//        $('#Productos').html(Productos);
//
//        // Actualiza el Total
//        var Total = $('#Total').html();
//        var Total = parseInt(Total)-parseInt(sPre);
//        $('#Total').html(Total);            
//        
//        // Remuevel el Elemento de los Seleccionados
//        $(this).remove();
//        
//    } );
