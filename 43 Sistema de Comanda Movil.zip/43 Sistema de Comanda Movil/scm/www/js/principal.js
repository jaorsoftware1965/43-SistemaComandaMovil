$(document).ready(function()
{    
    
    // Carga el Tipo de Usuario y Nombre al cargar la Página
    var paramstr    = window.location.search.substr(1);
    var iPosIgual   = paramstr.indexOf("=");
    var iPosPunto   = paramstr.indexOf(".");
    var iPos2Puntos = paramstr.indexOf(":");
    var sTipo       = paramstr.substr(0,iPosIgual);
    var sUser       = paramstr.substr(iPosIgual+1,iPosPunto-iPosIgual-1);
    var sNombre     = paramstr.substr(iPosPunto+1,iPos2Puntos-iPosPunto-1);
    var sHost       = paramstr.substr(iPos2Puntos+1);
    
    // Quita el Caracter Special y coloca los datos
    sNombre=sNombre.replace("%20", " ");
    $("#idTipo").html(sTipo);
    $("#idNombre").html(sNombre);

    // El host y el Usuario
    $("#idHost").html(sHost);
    $("#idUser").html(sUser);

    
    // Despliega los Contadores y los activa cada minuto
    fnDespliegaContadores();
    //setInterval(function(){ fnDespliegaContadores(); }, 5000);
    
    // Función para desplegar los contadores de Catálogos y Operaciones
    function fnDespliegaContadores()
    {        
        // Catálogos 
        fnCuentaUsuarios();                        
    }

    //----------------------------------------------------------------------------
    function fnCuentaUsuarios()
    {
        // Cuenta los usuarios del Sistema y los despliega.
        //$.post("http://10.0.0.6:80/scm/php/ajaxListarUsuarios.php",// No necesita el Puerto           
        //$.post("http://localhost/scm/www/php/ajaxListarUsuarios.php",       
        $.post("http://"+sHost+"/scm/www/php/ajaxListarUsuarios.php",               
        function(data) 
        {
            //var json = JSON.parse(data);            
            //$('#Usuarios').html((json.length<10 ? '0' : '') + json.length);
            $('#Usuarios').html((data.length<10 ? '0' : '') + data.length);            
            $('#tblOk').html($('#tblOk').html()+"Usuarios Ok ... ");
        },
        "json")
        .fail(function() {
            $('#tblFail').html($('#tblFail').html()+"Usuarios Fail ... ");
        })
        .always(function() 
        {
            //Llama al Siguiente Contador
            fnCuentaClases();
        });  
    }

    // Función para Contar las Clases de Productos
    function fnCuentaClases()
    {
        // Cuenta las Clases del Sistema
        $.post("http://localhost/scm/www/php/ajaxListarClases.php", 
        function(data) 
        {
            $('#Clases').html((data.length<10 ? '0' : '') + data.length);
            $('#tblOk').html($('#tblOk').html()+"Clases Ok ... ");
        }, 
        "json")
        .fail(function() 
        {
            $('#tblFail').html($('#tblFail').html()+"Clases Ok ... ");
        })
        .always(function() 
        {
            // Llama al Siguiente Contador
            fnCuentaProductos();
        });
    }

    // Función para Contar los Productos
    function fnCuentaProductos()
    {
        // Cuenta los Productos del Sistema
        $.post("http://localhost/scm/www/php/ajaxListarProductos.php", 
        function(data) 
        {
            $('#Productos').html((data.length<10 ? '0' : '') + data.length);
            $('#tblOk').html($('#tblOk').html()+"Productos Ok ... ");
        }, 
        "json")
        .fail(function() {
            $('#tblFail').html($('#tblFail').html()+"Productos Fail ... ");
        })
        .always(function() {
            //Llama al SIguiente Contador
            fnCuentaMesas();
        });
    }

    // Función para Contar Mesas de Servicio
    function fnCuentaMesas()
    {
        // Cuenta las Mesas del Sistema
        $.post("http://localhost/scm/www/php/ajaxListarMesas.php", 
        function(data) 
        {
            $('#Mesas').html((data.length<10 ? '0' : '') + data.length);
            $('#tblOk').html($('#tblOk').html()+"Mesas Ok ... ");
        }, 
        "json")
        .fail(function() {
            $('#tblFail').html($('#tblFail').html()+"Mesas Fail ... ");
        })
        .always(function() {
            //LLama al Siguiente Contador
            fnCuentaComentarios();
        });
    }

    // Función para Contar Comentarios
    function fnCuentaComentarios()
    {
        // Cuenta los Comentarios del Sistema
        $.post("http://localhost/scm/www/php/ajaxListarComentarios.php", 
        function(data) 
        {
            $('#Comentarios').html((data.length<10 ? '0' : '') + data.length);
            $('#tblOk').html($('#tblOk').html()+"Comentarios Ok ... ");
        }, 
        "json")
        .fail(function() {
            $('#tblFail').html($('#tblFail').html()+"Comentarios Fail ... ");
        })
        .always(function() {
            // Llama al Siguiente Contador
            fnCuentaServiciosActivos();
        });
    }

    // Función para contar los servicios activos
    function fnCuentaServiciosActivos()
    {     
        // Cuenta los Servicios Activos del Usuario
        $.post("http://localhost/scm/www/php/ajaxListarServiciosAct.php", 
        {'MeseroIde':sUser},   
        function(data) 
        {
            $('#ServiciosAct').html((data.length<10 ? '0' : '') + data.length);
            $('#tblOk').html($('#tblOk').html()+"Servicios Activos Ok ... ");
        }, 
        "json")
        .fail(function() {
            $('#tblFail').html($('#tblFail').html()+"Servicios Activos Fail ... ");
        })
        .always(function() 
        {
            // Llama a la Siguiente Función
            fnCuentaServiciosTotales();   
        });
    }

    // Función para contar los Servicios Totales del Usuario
    function fnCuentaServiciosTotales()
    {
        // Cuenta los Servicios Totales del Usuario
        $.post("http://localhost/scm/www/php/ajaxListarServiciosTot.php", 
        {'MeseroIde':sUser},   
        function(data) 
        {
            $('#ServiciosTot').html((data.length<10 ? '0' : '') + data.length);
            $('#tblOk').html($('#tblOk').html()+"Servicios Totales Ok ... ");
        }, 
        "json")
        .fail(function() {
            $('#tblFail').html($('#tblFail').html()+"Servicios Totales Fail ... ");
        })
        .always(function() 
        {
            // Llama a la Siguiente Función
            fnCuentaComandasActivas();   
        });
    }

    // Función para contar las Comandas Activas
    function fnCuentaComandasActivas()
    {
        // Cuenta las Comandas Activas del Usuario
        $.post("http://localhost/scm/www/php/ajaxListarComandasAct.php", 
        {'MeseroIde':sUser},   
        function(data) 
        {
            $('#ComandasAct').html((data.length<10 ? '0' : '') + data.length);
            $('#tblOk').html($('#tblOk').html()+"Comandas Activas Ok ... ");
        }, 
        "json")
        .fail(function() {
            $('#tblFail').html($('#tblFail').html()+"Comandas Activas Fail ... ");
        })
        .always(function() 
        {
            // Llama a la Siguiente Función
            fnCuentaComandasTotales();   
        });
    }

    // Funcion para Contar Comandas Totales
    function fnCuentaComandasTotales()
    {        
        // Cuenta las Comandas Totales del Usuario
        $.post("http://localhost/scm/www/php/ajaxListarComandasTot.php", 
        {'MeseroIde':sUser},   
        function(data) 
        {
            $('#ComandasTot').html((data.length<10 ? '0' : '') + data.length);
            $('#tblOk').html($('#tblOk').html()+"Comandas Totales Ok ... ");
        }, 
        "json")
        .fail(function() {
            $('#tblFail').html($('#tblFail').html()+"Comandas Totales Fail ... ");
        })
        .always(function() 
        {
            // Llama a la Siguiente Función
            fnCuentaComandasActivasEnCocina();   
        });

    }

    function fnCuentaComandasActivasEnCocina()
    {        
        // Cuenta las Comandas activas en Cocina de Usuario
        $.post("http://localhost/scm/www/php/ajaxListarCocinaAct.php", 
        {'MeseroIde':sUser},   
        function(data) 
        {
            $('#CocinaAct').html((data.length<10 ? '0' : '') + data.length);
            $('#tblOk').html($('#tblOk').html()+"Comandas Activas en Cocina Ok ... ");
        }, 
        "json")
        .fail(function() {
            $('#tblFail').html($('#tblFail').html()+"Comandas Activas en Cocina Fail ... ");
        })
        .always(function() 
        {
            // Llama a la Siguiente Función
            fnCuentaComandasTotalesEnCocina();   
        });
    }

    // Función para Contar Comandas Totales en Cocina
    function fnCuentaComandasTotalesEnCocina()
    {        
        // Cuenta las Comandas Totales en Cocina de Usuario
        $.post("http://localhost/scm/www/php/ajaxListarCocinaTot.php", 
        {'MeseroIde':sUser},   
        function(data) 
        {
            $('#CocinaTot').html((data.length<10 ? '0' : '') + data.length);
            $('#tblOk').html($('#tblOk').html()+"Comandas Totales en Cocina Ok ... ");
        }, 
        "json")
        .fail(function() {
            $('#tblFail').html($('#tblFail').html()+"Comandas Totales en Cocina Fail ... ");
        })
        .always(function() 
        {
            // Llama a la Siguiente Función
            fnCuentaComandasActivasEnBarra();   
        });
    }

    function fnCuentaComandasActivasEnBarra()
    {        
        // Cuenta las Comandas Activas en Barra de su Usuario
        $.post("http://localhost/scm/www/php/ajaxListarBarraAct.php", 
        {'MeseroIde':sUser},   
        function(data) 
        {
            $('#BarraAct').html((data.length<10 ? '0' : '') + data.length);
            $('#tblOk').html($('#tblOk').html()+"Comandas Activas en Barra Ok ... ");
        }, 
        "json")
        .fail(function() {
            $('#tblFail').html($('#tblFail').html()+"Comandas Activas en Barra Fail ... ");
        })
        .always(function() 
        {
            // Llama a la Siguiente Función
            fnCuentaComandasTotalesEnBarra();   
        });
    }

    function fnCuentaComandasTotalesEnBarra()
    {
        // Cuenta las Comandas Totales en Barra de su Usuario
        $.post("http://localhost/scm/www/php/ajaxListarBarraTot.php", 
        {'MeseroIde':sUser},   
        function(data) 
        {
            $('#BarraTot').html((data.length<10 ? '0' : '') + data.length);
            $('#tblOk').html($('#tblOk').html()+"Comandas Totales en Barra Ok ... ");
        }, 
        "json")
        .fail(function() {
            $('#tblFail').html($('#tblFail').html()+"Comandas Totales en Barra Fail ... ");
        })
        .always(function() 
        {
            // Llama a la Siguiente Función
            fnCuentaComandasActivasGral();   
        });
    }
    
    function fnCuentaComandasActivasGral()
    {        
        // Cuenta las Comandas de Cocina y Barra Activas de su Usuario
        $.post("http://localhost/scm/www/php/ajaxListarEntregas.php", 
        {'MeseroIde':sUser},   
        function(data) 
        {
            $('#EntregasAct').html((data.length<10 ? '0' : '') + data.length);
            $('#tblOk').html($('#tblOk').html()+"Comandas Gral Activas Ok ... ");
        }, 
        "json")
        .fail(function() {
            $('#tblFail').html($('#tblFail').html()+"Comandas Gral Activas Fail ... ");
        })
        .always(function() 
        {
            // Ejecuta el Siguiente Contador
            fnCuentaComandasGralTotales();
        });
    }

    function fnCuentaComandasGralTotales()
    {        
        // Cuenta las Comandas Totales de Cocina y Barra
        $.post("http://localhost/scm/www/php/ajaxListarEntregasTot.php", 
        {'MeseroIde':sUser},   
        function(data) 
        {
            $('#EntregasTot').html((data.length<10 ? '0' : '') + data.length);
            $('#tblOk').html($('#tblOk').html()+"Comandas Gral Totales Ok ... ");
        }, 
        "json")
        .fail(function() {
            $('#tblFail').html($('#tblFail').html()+"Comandas Gral Totales Fail ... ");
        })
        .always(function() 
        {
            // Ejecuta el Siguiente Contador
            fnCuentaServiciosActivosEnCaja();
        });

    }

    // Función para contar los Servicios Activos en Caja
    function fnCuentaServiciosActivosEnCaja()
    {        
        // Cuenta los Servicios Activos en Caja
        $.post("http://localhost/scm/www/php/ajaxListarCaja.php", 
        {'MeseroIde':sUser},   
        function(data) 
        {
            $('#CajaAct').html((data.length<10 ? '0' : '') + data.length);
            $('#tblOk').html($('#tblOk').html()+"Servicios Activos en Caja Ok ... ");
        }, 
        "json")
        .fail(function() {
            $('#tblFail').html($('#tblFail').html()+"Servicios Activos en Caja Fail ... ");
        })
        .always(function() 
        {
            // Ejecuta el Siguiente Contador
            fnCuentaServiciosTotalesEnCaja();
        });
    }

    function fnCuentaServiciosTotalesEnCaja()
    {        
        // Cuenta los Servicios Totales en Caja
        $.post("http://localhost/scm/www/php/ajaxListarCajaTot.php", 
        {'MeseroIde':sUser},   
        function(data) 
        {
            $('#CajaTot').html((data.length<10 ? '0' : '') + data.length);
            $('#tblOk').html($('#tblOk').html()+"Servicios Totales en Caja Ok ... ");
        }, 
        "json")
        .fail(function() {
            $('#tblFail').html($('#tblFail').html()+"Servicios Totales en Caja Fail ... ");
        })
        .always(function() 
        {
           
        });
    }


    //----------------------------------------------------------------------------
    
    // Captura el evento Click de las opciones del Menu
    $('#opcUsuarios').click(function(e) 
    {        
        // Ejecuta Página Pasando el Usuario
        window.location.href = "usuarios.php?"+$('#idUser').html()+":"+sHost;
    });
    
    $('#opcClases').click(function(e) 
    {        
        // Ejecuta Página Pasando el Usuario
        window.location.href = "clases.php?"+$('#idUser').html()+":"+sHost;;
    });

    $('#opcProductos').click(function(e) 
    {        
        // Ejecuta Página Pasando el Usuario
        window.location.href = "productos.php?"+$('#idUser').html()+":"+sHost;
    });

    $('#opcMesas').click(function(e) 
    {        
        // Ejecuta Página Pasando el Usuario
        window.location.href = "mesas.php?"+$('#idUser').html()+":"+sHost;
    });
    
    $('#opcComentarios').click(function(e) 
    {        
        // Ejecuta Página Pasando el Usuario
        window.location.href = "comentarios.php?"+$('#idUser').html()+":"+sHost;
    });

    $('#opcServicios').click(function(e) 
    {        
        // Ejecuta Página Pasando el Usuario
        window.location.href = "servicios.php?"+$('#idUser').html()+":"+sHost;
    });
    
    $('#opcComandas').click(function(e) 
    {        
        // Ejecuta Página Pasando el Usuario
        window.location.href = "comandas.php?"+$('#idUser').html()+"&";
    });

    $('#opcCocina').click(function(e) 
    {        
        // Ejecuta Página Pasando el Usuario
        window.location.href = "cocina.php?"+$('#idUser').html()+":"+sHost;
    });
    
    $('#opcBarra').click(function(e) 
    {        
        // Ejecuta Página Pasando el Usuario
        window.location.href = "barra.php?"+$('#idUser').html()+":"+sHost;
    });
    
    $('#opcEntregas').click(function(e) 
    {        
        // Ejecuta Página Pasando el Usuario
        window.location.href = "entregas.php?"+$('#idUser').html()+":"+sHost;
    });
        
    $('#opcCaja').click(function(e) 
    {        
        // Ejecuta Página Pasando el Usuario
        window.location.href = "caja.php?"+$('#idUser').html()+":"+sHost;
    });
    
    
    // ---------------------------------------------------------------------------
    // Consultas
    // ---------------------------------------------------------------------------
    $('#opcVentas').click(function(e) 
    {        
        // Ejecuta Página Pasando el Usuario
        window.location.href = "ventas.php?"+$('#idUser').html()+":"+sHost;
    });
});

// Trabajo Perfecto en el App Preview del Dispositivo Cuenta los usuarios del Sistema y los despliega.
//        $.post("http://10.0.0.6:80/scm/php/ajaxListarUsuarios.php",         
//        function(data) 
//        {
//            var json = JSON.parse(data);
//            alert(json.length);
//            $('#Usuarios').html((json.length<10 ? '0' : '') + json.length);
//        });


//        // Cuenta los usuarios del Sistema y los despliega.        
//        $.ajax({            
//            url :"http://10.0.0.6:80/scm/php/ajaxListarUsuarios.php", 
//            type:'post',            // Método de transferencia      
//            crossDomain: true,
//            async: true,
//            beforeSend: function()  // Se ejecuta antes de
//                {
//                    $("#Usuarios").html("Calculando ...");
//                }, 
//            success: function(respuesta)  // En respuesta viene lo que devolvio sumar.php
//            {
//                var json = JSON.parse(respuesta);
//                $('#Usuarios').html((json.length<10 ? '0' : '') + json.length);
//            }
//        }); 
