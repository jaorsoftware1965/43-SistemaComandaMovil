
$(document).ready(function()
{          
    $("#idResultado").html("sHost");
    // Elimina y Controla el Submit
    $('form[name=sesion]').submit(function(){
        
        // Declaro una variable para el Host
        var sHost = "localhost";

        sHost = $('#idHost').val();
        // Parámetros para ajax
        var parametros =
        {
            "UsuarioIde":$('#idUsuario').val(),
            "UsuarioCve":$('#idClave').val()
        };
                
       
        // Función para solicitar acceso
        $.ajax({
                data:parametros,        // Parametros para ajax              
                url :"http://"+sHost+"/scm/www/php/ajaxAcceso.php",
                type:'post',            // Método de transferencia      
//                crossDomain: true,
//                async: true,
                headers: {
                    'Access-Control-Allow-Origin': '*.*',
                    
                    'connect-src': 'https://10.0.0.6'
                },
                beforeSend: function()  // Se ejecuta antes de
                {
                    $("#idResultado").html("Accediendo al Servidor:"+sHost);
                },                
                success: function(respuesta)
                {                    
                    //alert(respuesta);
                    $("#idResultado").html(respuesta);
                    var sResultado = respuesta;
                    var json = JSON.parse(respuesta);
                    $("#idResultado").html(json[0].nom);
                    if (sResultado.indexOf("Error")<0)                        
                       window.location.href="principal.php?"+json[0].tip+
                                        "="+json[0].ide+"."+json[0].nom+":"+sHost;
                }
              },"json"); 


                
        // Siempre retornamos false para evitar el Submit
        return false;
    });
});

//        $.post("http://localhost/scm/php/ajaxAcceso.php",
//               {'UsuarioIde':$('#idUsuario').val(),
//                'UsuarioCve':$('#idClave').val(),
//                'UsuarioTip':$('#idTipo').val()},
//        function(data)
//        {
//            var Datos = data;
//             for (var i=0; i<data.length; i++) 
//                {
//                    $("#idResultado").html(Datos[0].nom);
//                    //sel.append('<li>' + data[i].ide+ '-'+data[i].nom + '</a></li>');
//                }
//              //$("#idResultado").html(respuesta[0].nom);     
//              //$.mobile.changePage('principal.html',{reload:true}); 
//        });


//$.post("http://localhost/scm/php/acceso.php",
//               {'UsuarioIde':$('#idUsuario').val(),
//                'UsuarioCve':$('#idClave').val(),
//                'UsuarioTip':$('#idTipo').val()},
//        function(respuesta)
//        {
//              $("#idResultado").html(respuesta);     
//              $.mobile.changePage('principal.html',{reload:true}); 
//        });


//$.post("http://localhost/scm/php/ajaxListarUsuarios.php", 
//             //{'idcategory' : idc },
//             function(data) 
//             {
//                var sel = $("#Usuarios");
//                //sel.empty();
//                for (var i=0; i<data.length; i++) 
//                {
//                    sel.append('<li>' + data[i].ide+ '-'+data[i].nom + '</a></li>');
//                }
//             }, 
//             "json");