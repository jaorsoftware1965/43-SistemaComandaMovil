$(document).ready(function()
{    
    // Carga los parámetros
    var paramstr = window.location.search.substr(1);
    
    // Obtiene la posición de los ":"
    var iPos2Puntos = paramstr.indexOf(":");

    // Obtiene el Usuario
    var sUser = paramstr.substr(0,iPos2Puntos);    
    $("#idUser").html(sUser);    
    $("#idUser2").html(sUser); 
    
    // Obtiene el Host
    var sHost = paramstr.substr(iPos2Puntos + 1);    
    $("#idHost").html(sHost); 
    
    // Carga los Productos al Cargar la Página
    fnCargaProductos();             

    // Ejecuta Ajax para cargar Clases de Productos        
    $.post("http://"+sHost+"/scm/www/php/ajaxListarClases.php", 
    function(data) 
    {         
        for (var i=0; i<data.length; i++) 
        {
            //'<option value=1>My option</option>'
            $('#idCla').append('<option value='+ data[i].num+'>'+data[i].nom+'</option>');
        }
    }, 
    "json")
    .fail(function() {
            alert("Error en la Carga de Clases");
    });  

    // Captura el Evento Click sobre la Tabla
    $('#tblProductos tbody').on( 'click', 'tr', function () 
    {       
        if ($(this).hasClass('trSelected') ) 
        {
            // Elimina la Clase del row
            $(this).removeClass('trSelected');
            
            // Borra el Ide Seleccionado
            $('#idIdeSelected').val("");
        }
        else 
        {
            // Remueve los Seleccionados que haya
            $('tr.trSelected').removeClass('trSelected');// Para que solo sea uno
            // Añade la clase  Seleccionada
            $(this).addClass('trSelected');  
            // Coloca el Ide Seleccionado
            $('#idIdeSelected').val($(this).find('td').eq(0).text());
            $('#idNomSelected').val($(this).find('td').eq(1).text());
            $('#idPreSelected').val($(this).find('td').eq(2).text());
            $('#idClaSelected').val($(this).find('td').eq(4).text());
            
        }
    } );    
    
    // Controla el Evento antes de que se muestre la forma 
    //$(document).on('pagebeforeshow', '#pageAbcProductos', function() Funciona
    //$(document).on('pagecreate', '#pageAbcProductos', function() Funciona    
    $(document).on('pageshow', '#pageAbcProductos', function()
    { 
        // Verifica si es inserción
        if ($('#idAC').html()=="Insertar")
        {
            // Coloca el Foco en el Ide
            $('#idIde').focus();
        }
        else
        {
            // Coloca el Foco en el Nombre
            $('#idNom').focus();
        }              
    });  

    // Captura el evento Click para el Botón de Aceptar
    $('#idAceptar').click(function(e) 
    {
        // Variable para el Mensaje
        var sMensaje="";
            
        // Valida que haya captura los datos
        if ($('#idIde').val()=="")
            sMensaje=" La Identificación,";
        
        if ($('#idNom').val()=="")
            sMensaje=sMensaje + " El Nombre,";        
        
        if ($('#idPre').val()=="")
            sMensaje=sMensaje + " El Precio,";
        
        if ($("#idCla option:selected" ).text()=="")
            sMensaje=sMensaje + " La Clase,";
         
        
        // Valida si despliega el Mensaje
        if (sMensaje!="")
        {
            sMensaje="Debe capturar los siguiente datos:"+sMensaje.substring(0,sMensaje.length-1);
            $('#idResultado').html(sMensaje);            
        }
        else
        {
            // Verifica si es inserción o modificacion
            if ($('#idAC').html()=="Insertar")
            {
                // Reliza la Inserción
                $.post("http://"+sHost+"/scm/www/php/ajaxProductoIns.php",
                {
                    'ProductoIde':$('#idIde').val(),
                    'ProductoNom':$('#idNom').val(),
                    'ProductoPre':$('#idPre').val(),        
                    'ClaseNum':$('#idCla').val()},
                function(data)
                {
                    // Coloca los datos
                    $("#idResultado").html(data);     
                    if (data.indexOf("Error")<0)
                    {
                        //window.location.href="productos.html?"+$("#idUser").html();
                        fnCargaProductos();
                        window.history.back();
                    }
                })
                .fail(function() {
                    $('#idResultado').html("Error al Inesperado al Insertar Producto");
                });                                                  
            }
            else
            {
                // Realiza la Modificación
                $.post("http://"+sHost+"/scm/www/php/ajaxProductoMod.php",
                {
                    'ProductoIde':$('#idIde').val(),
                    'ProductoNom':$('#idNom').val(),
                    'ProductoPre':$('#idPre').val(),        
                    'ClaseNum':$('#idCla').val()
                },
                function(data)
                {
                    // Coloca los datos
                    $("#idResultado").html(data);     
                    if (data.indexOf("Error")<0)
                    {    
                        //window.location.href="productos.html?"+$("#idUser").html();
                        fnCargaProductos();
                        window.history.back();
                    }
                })
                .fail(function() {
                    $('#idResultado').html("Error Inesperado al Modificar Producto");
                });         
            }
        }               
    });
    
    // Insertar Producto
    $('#idInsertar').click(function(e) 
    {
        // Habilita el Ide
        $('#idIde').prop( "disabled", false);
        // Inicializa datos
        $('#idIde').val("");
        $('#idNom').val("");
        $('#idPre').val("");        
        $('#idCla').val("");        
        $('#idCla').trigger("change");                 
        $('#idAC').html('Insertar');
        $('#idResultado').html("Ready");            
        $.mobile.changePage("#pageAbcProductos");        
    });

    // Modificar Producto
    $('#idModificar').click(function(e) 
    {
        // Verifica que haya un registro seleccionado
        if ($('#idIdeSelected').val()=="")
        {
            $('#idOperacion').html("Modificar");
            $( "#popupDialog").popup( "open" );
            setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);
        }
        else
        {
            // Deshabilita el Ide
            $('#idIde').prop( "disabled", true );
            
            // Coloca los datos a Modificar
            $('#idIde').val($('#idIdeSelected').val());
            $('#idNom').val($('#idNomSelected').val());
            $('#idPre').val($('#idPreSelected').val());
            $('#idCla').val($('#idClaSelected').val()); 
            $('#idCla').trigger("change");
            $('#idAC').html("Modificar");
            // Limpia el Mensaje Previo y Carga la Página
            $('#idResultado').html("Ready");            
            $.mobile.changePage("#pageAbcProductos");                                     
        }
        
    });

    // Eliminar Usuario
    $('#idEliminar').click(function(e) 
    {
        // Verifica que haya un registro seleccionado
        if ($('#idIdeSelected').val()=="")
        {
            $('#idOperacion').html("Eliminar");
            $( "#popupDialog").popup( "open" );
            setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);   
        }
        else
        {
            // ajax para Eliminar los datos
            $.post("http://"+sHost+"/scm/www/php/ajaxProductoEli.php",
            {
                'ProductoIde':$('#idIdeSelected').val()
            },
            function(data)
            {                
                // Valida si hubo error
                if (data.indexOf("Error")<0)                        
                {
                    // Carga de Nuevo la Ventana
                    //window.location.href="productos.html?"+$("#idUser").html();
                    fnCargaProductos();
                }
                else
                {
                    $('#idMensaje').html(data);
                    $( "#popupDialog").popup( "open" );
                }                   
            })
            .fail(function() 
            {
                $('#idMensaje').html("Error Inesperado al Eliminar Producto");
                $( "#popupDialog").popup( "open" );
            });
        }        
    });

    // Carga los Productos
    function fnCargaProductos()
    {
        // Carga los Productos al Cargar la Página
        $.post("http://"+sHost+"/scm/www/php/ajaxListarProductos.php", 
        function(data) 
        {
            // Elimina Productos Previos
            $('#tblProductos tbody tr').empty();
            for (var i=0; i<data.length; i++) 
            {
                $('#tblProductos tr:last').after('<tr><td>'+ data[i].ide+'</td><td>'+ data[i].nom+'</td><td align="right">'+data[i].pre+'</td><td>'+
                data[i].cla+'</td><td style="display:none;">'+data[i].cve+'</td></tr>');
            }
        }, 
         "json")
        .fail(function() {
            alert("Error en la Carga de Productos");
        });  
    }
});
