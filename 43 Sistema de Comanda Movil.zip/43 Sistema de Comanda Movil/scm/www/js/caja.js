$(document).ready(function()
{    
    // Carga el Nombre al cargar la Página
    var sUser  = window.location.search.substr(1);
    $("#idUser").html(sUser);    
    
    
    // Carga los Servicios a Cobrar en la Caja
    fnCargaCaja();
        
    // Captura el Evento Click sobre la Tabla
    $('#tblCaja tbody').on( 'click', 'tr', function () 
    {   
        // Cloca los datos en la Página de Cobro
        $('#idServicio').val($(this).find('td').eq(0).text());
        $('#idFecha').val($(this).find('td').eq(1).text());
        $('#idMesa').val($(this).find('td').eq(2).text());
        $('#idMesero').val($(this).find('td').eq(3).text());
        $('#idTotal').val($(this).find('td').eq(4).text());
        
        // Limpia el Pago y el Cambio
        $('#idPago').val("0");
        $('#idCambio').val("0");                
            
        // Cambia de Página
        $.mobile.changePage("#pageCobro"); 
        
    });    
    
    
    // Captura el evento Click para el Botón de Calcular el Cambio
    $('#btnCalcular').click(function(e) 
    {
        // Obtiene total y pago
        var iTotal = $('#idTotal').val();
        var iPago  = $('#idPago').val();
        
        // Calcula el Cambio
        var iCambio = parseInt(iPago) - parseInt(iTotal);
        
        // Verifica que el pago sea mayor que el Total
        if (iCambio>=0)
        {                        
            // Coloca el cambio
            $('#idCambio').val(iCambio);
            
            // Actualiza el Mensaje
            $('#idResultado').html("Cambio Calculado");            
        }
        else
        {
            // Coloca el Mensaje
            $('#idResultado').html("El pago no cubre el Total del Servicio");            
        }
    });
    
    // Captura el evento Click para el Botón de Aceptar
    $('#btnAceptar').click(function(e) 
    {
        // Reliza la Modificación
        $.post("http://localhost/scm/php/ajaxServicioCob.php",
        {'ServicioNum':$('#idServicio').val()},
         function(data)
         {
            // Coloca los datos
            $("#idResultado").html(data);     
            if (data.indexOf("Error")<0)
            {   
                $('#tblCaja tbody').empty();
                fnCargaCaja();
                window.history.back();
            }
         });  
        
    });
    
    // Carga los Servicios a Cobrar en Caja
    function fnCargaCaja()
    {        
        // Carga los Servicios a Cobrar
        $.post("http://localhost/scm/php/ajaxListarCaja.php", 
         function(data) 
         {
            // Ciclo para agregar
            for (var i=0; i<data.length; i++) 
            {
                $('#tblCaja tbody').append('<tr><td>'+ data[i].serv+'</td><td>'+ data[i].fech+'</td><td>'+data[i].mesa+'</td><td>'+data[i].mese+'</td><td>'+data[i].tota+'</td></tr>');
            }
         }, 
         "json");
    }
});
