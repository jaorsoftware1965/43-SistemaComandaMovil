$(document).ready(function()
{    
    // Carga el Nombre al cargar la Página
    var sUser  = window.location.search.substr(1);
    $("#idUser").html(sUser);    
    
    
    // Carga los Productos a Preparar en la Barra
    fnCargaBarra();
        
    // Captura el Evento Click sobre la Tabla
    $('#tblBarra tbody').on( 'click', 'tr', function () 
    {       

        // Obtiene los datos necesarios para actualizar
        var Servicio = $(this).find('td').eq(0).text();
        var Mesa     = $(this).find('td').eq(1).text();
        var Registro = $(this).find('td').eq(2).text();
                
        // Realiza la Modificación
        $.post("http://localhost/scm/php/ajaxComandaSta.php",
        {'ServicioNum':Servicio,
         'MesaNum':Mesa,
         'ProductoReg':Registro,
         'ProductoSta':"P"},
         function(data)
         {
            
            // Verifica que no haya habido error
            if (data.indexOf("Error")<0)                        
            {
                // Elimina todo y vuelve a Cargar
                $('#tblBarra tbody tr').empty();
                fnCargaBarra();
            }
            else
            {
                $('#idMensaje').html(data);
                $( "#popupDialog").popup( "open" );
                setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);            
            }
         });
        
    });    
    
    
    // Carga los Productos a Preparar
    function fnCargaBarra()
    {        
        // Carga los Productos a Preparar
        $.post("http://localhost/scm/php/ajaxListarBarra.php", 
         function(data) 
         {
            // Ciclo para agregar
            for (var i=0; i<data.length; i++) 
            {
                $('#tblBarra tr:last').after('<tr><td>'+ data[i].ser+'</td><td>'+data[i].mes+'</td><td>'+data[i].reg+'</td><td>'+data[i].pro+'</td><td>'+data[i].com+'</td></tr>');
            }
         }, 
         "json");
    }
});
