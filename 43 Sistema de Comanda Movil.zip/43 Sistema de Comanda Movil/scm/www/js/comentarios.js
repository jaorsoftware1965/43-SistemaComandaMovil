$(document).ready(function()
{    
     // Carga los parámetros
    var paramstr = window.location.search.substr(1);
    
    // Obtiene la posición de los ":"
    var iPos2Puntos = paramstr.indexOf(":");

    // Obtiene el Usuario
    var sUser = paramstr.substr(0,iPos2Puntos);    
    $("#idUser").html(sUser);    
    $("#idUser2").html(sUser); 
    
    // Obtiene el Host
    var sHost = paramstr.substr(iPos2Puntos + 1);    
    $("#idHost").html(sHost);

    // Carga las Comentarios al Cargar la Página
    fnCargaComentarios();
        
    // Captura el Evento Click sobre la Tabla
    $('#tblComentarios tbody').on( 'click', 'tr', function () 
    {       
        if ($(this).hasClass('trSelected') ) 
        {
            // Elimina la Clase del row
            $(this).removeClass('trSelected');
            
            // Borra el Ide Seleccionado
            $('#idNumSelected').val("");
        }
        else 
        {
            // Remueve los Seleccionados que haya
            $('tr.trSelected').removeClass('trSelected');// Para que solo sea uno
            // Añade la clase  Seleccionada
            $(this).addClass('trSelected');  
            // Coloca el Ide Seleccionado
            $('#idNumSelected').val($(this).find('td').eq(0).text());
            $('#idDscSelected').val($(this).find('td').eq(1).text());
        }
    } );    
    
    // Controla el Foco al Cargar la Página
    $(document).on('pageshow', '#pageAbcComentarios', function()
    { 
        // Coloca el Foco en la Descripción
        $('#idDsc').focus();                      
    });

    // Captura el evento Click para el Botón de Aceptar
    $('#idAceptar').click(function(e) 
    {

        // Verifica si ha capturado la Descripción
        if ($('#idDsc').val()=="")
        {
            $('#idResultado').html("Debe capturar la Descripción del Comentario.");
        }
        else
        {                                    
            // Verifica si es inserción o modificacion
            if ($('#idAC').html()=="Insertar")
            {
                // Reliza la Inserción
                $.post("http://"+sHost+"/scm/www/php/ajaxComentarioIns.php",
                {
                    'ComentarioDsc':$('#idDsc').val()
                },
                function(data)
                {
                    // Coloca los datos
                    $("#idResultado").html(data);     
                    if (data.indexOf("Error")<0)                        
                    {
                        //window.location.href="mesas.html?"+$("#idUser").html();
                        fnCargaComentarios();
                        window.history.back();
                    }
                })
                .fail(function() {
                    $('#idResultado').html("Error al Inesperado al Insertar Comentario");
                });                       
            }
            else
            {
                // Realiza la Modificación
                $.post("http://"+sHost+"/scm/www/php/ajaxComentarioMod.php",
                {
                    'ComentarioNum':$('#idNum').val(),
                    'ComentarioDsc':$('#idDsc').val()
                },
                function(data)
                {
                    // Coloca los datos
                    $("#idResultado").html(data);     
                    if (data.indexOf("Error")<0)                        
                    {
                        //window.location.href="mesas.html?"+$("#idUser").html();
                        fnCargaComentarios();
                        window.history.back();
                    }
                })
                .fail(function() {
                    $('#idResultado').html("Error Inesperado al Modificar Comentario");
                });       
            }
        }                       
    });
    
    // Insertar Comentario
    $('#idInsertar').click(function(e) 
    {            
        $('#idAC').html('Insertar');
        $('#idResultado').html("Ready");
        // Inicializa datos
        $('#idNum').val("Automático");
        $('#idNum').prop( "disabled", true);
        $('#idDsc').val("");            
        $.mobile.changePage("#pageAbcComentarios");
    });

    // Modificar Comentario
    $('#idModificar').click(function(e) 
    {
        // Verifica que haya un registro seleccionado
        if ($('#idNumSelected').val()=="")
        {
            $('#idOperacion').html("Modificar");
            $( "#popupDialog").popup( "open" );
            setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);
        }
        else
        {            
            // Coloca los datos a Modificar
            $('#idNum').val($('#idNumSelected').val());
            $('#idDsc').val($('#idDscSelected').val());
            $('#idAC').html("Modificar");
            $('#idResultado').html("Ready");            
            $.mobile.changePage("#pageAbcComentarios");                                     
        }        
    });

    // Eliminar Comentario
    $('#idEliminar').click(function(e) 
    {
        // Verifica que haya un registro seleccionado
        if ($('#idNumSelected').val()=="")
        {
            $('#idOperacion').html("Eliminar");
            $( "#popupDialog").popup( "open" );
            setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);   
        }
        else
        {
            // ajax para Eliminar los datos
            $.post("http://"+sHost+"/scm/www/php/ajaxComentarioEli.php",
            {
                'ComentarioNum':$('#idNumSelected').val()
            },
            function(data)
            {                
                // Valida si hubo error
                if (data.indexOf("Error")<0)                        
                {
                    // Carga de Nuevo la Ventana
                    //window.location.href="comentarios.html?"+$("#idUser").html();
                    fnCargaComentarios();                        
                }
                else
                {
                    $('#idMensaje').html(data);
                    $( "#popupDialog").popup( "open" );
                }
                   
            })
            .fail(function() 
            {
                $('#idMensaje').html("Error Inesperado al Eliminar Mesa");
                $( "#popupDialog").popup( "open" );
            });
        }        
    });

    // Carga los Comentarios
    function fnCargaComentarios()
    {
        // Carga las Comentarios al Cargar la Página
        $.post("http://"+sHost+"/scm/www/php/ajaxListarComentarios.php", 
        function(data) 
        {
            // Elimina Comentarios Previos
            $('#tblComentarios tbody tr').empty();
            for (var i=0; i<data.length; i++) 
            {
                $('#tblComentarios tr:last').after('<tr><td>'+ data[i].num+'</td><td>'+data[i].dsc+'</td></tr>');
            }
        }, 
        "json")
        .fail(function() {
            alert("Error en la Carga de Comentarios");
        });
    }
});

