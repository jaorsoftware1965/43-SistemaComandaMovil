$(document).ready(function()
{        
    // Carga los parámetros
    var paramstr = window.location.search.substr(1);
    
    // Obtiene la posición de los ":"
    var iPos2Puntos = paramstr.indexOf(":");

    // Obtiene el Usuario
    var sUser = paramstr.substr(0,iPos2Puntos);    
    $("#idUser").html(sUser);    
    $("#idUser2").html(sUser); 
    
    // Obtiene el Host
    var sHost = paramstr.substr(iPos2Puntos + 1);    
    $("#idHost").html(sHost); 
    
    // Carga los Usuarios al Cargar la Página
    fnCargaUsuarios();
        
    // Captura el Evento Click sobre la Tabla
    $('#tblUsuarios tbody').on( 'click', 'tr', function () 
    {       
        if ($(this).hasClass('trSelected') ) 
        {
            // Elimina la Clase del row
            $(this).removeClass('trSelected');
            
            // Borra el Ide Seleccionado
            $('#idIdeSelected').val("");
        }
        else 
        {
            // Remueve los Seleccionados que haya
            $('tr.trSelected').removeClass('trSelected');// Para que solo sea uno
            // Añade la clase  Seleccionada
            $(this).addClass('trSelected');  
            // Coloca el Ide Seleccionado
            $('#idIdeSelected').val($(this).find('td').eq(0).text());
            $('#idCveSelected').val($(this).find('td').eq(1).text());
            $('#idNomSelected').val($(this).find('td').eq(2).text());
            $('#idTipSelected').val($(this).find('td').eq(3).text());
            
        }
    } );    

    $(document).on('pageshow', '#pageAbcUsuarios', function()
    { 
        // Verifica si es inserción
        if ($('#idAC').html()=="Insertar")
        {
            // Coloca el Foco en el Ide
            $('#idIde').focus();
        }
        else
        {
            // Coloca el Foco en el Nombre
            $('#idCve').focus();
        }               
    });  

    
    // Captura el evento Click para el Botón de Aceptar
    $('#idAceptar').click(function(e) 
    {
        // Variable para el Mensaje
        var sMensaje="";
            
        // Valida que haya captura los datos
        if ($('#idIde').val()=="")
            sMensaje=" La Identificación ";
        
        if ($('#idCve').val()=="")
            sMensaje=sMensaje + " La Clave ";        
        
        if ($('#idNom').val()=="")
            sMensaje=sMensaje + " El Nombre ";

        if ($('#idTip').val()==null)
            sMensaje=sMensaje + " El Tipo de Usuario";    
              
        
        // Valida si despliega el Mensaje
        if (sMensaje!="")
        {
            sMensaje="Debe capturar los siguiente datos:"+sMensaje.substring(0,sMensaje.length);
            $('#idResultado').html(sMensaje);            
        }
        else
        {
            // Verifica si es inserción o modificacion
            if ($('#idAC').html()=="Insertar")
            {
                // Reliza la Inserción
                $.post("http://"+sHost+"/scm/www/php/ajaxUsuarioIns.php",
                {
                    'UsuarioIde':$('#idIde').val(),
                    'UsuarioCve':$('#idCve').val(),
                    'UsuarioNom':$('#idNom').val(),        
                    'UsuarioTip':$('#idTip').val()
                },
                function(data)
                {
                    // Coloca los datos
                    $("#idResultado").html(data);     
                    if (data.indexOf("Error")<0)                        
                    {
                        //window.location.href="usuarios.html?"+$("#idUser").html();
                        fnCargaUsuarios();
                        window.history.back();
                    }
                })
                .fail(function() {
                    $('#idResultado').html("Error al Inesperado al Insertar Usuario");
                });                         
            }
            else
            {
                // Realiza la Modificación
                $.post("http://"+sHost+"/scm/www/php/ajaxUsuarioMod.php",
                {
                    'UsuarioIde':$('#idIde').val(),
                    'UsuarioCve':$('#idCve').val(),
                    'UsuarioNom':$('#idNom').val(),        
                    'UsuarioTip':$('#idTip').val()
                },
                function(data)
                {
                    // Coloca los datos
                    $("#idResultado").html(data);     
                    if (data.indexOf("Error")<0)
                    {
                        //window.location.href="usuarios.html?"+$("#idUser").html();
                        fnCargaUsuarios();
                        window.history.back();
                    }
                })
                .fail(function() {
                    $('#idResultado').html("Error Inesperado al Modificar Usuario");
                });         
            }
        }               
    });
    
    // Insertar Usuario
    $('#idInsertar').click(function(e) 
    {
        // Habilita el Ide
        $('#idIde').prop( "disabled", false );            
        $('#idAC').html('Insertar');
        $('#idResultado').html("Ready");            

        // Blanquea los datos
        $('#idIde').val("");
        $('#idCve').val("");
        $('#idNom').val("");
        $('#idTip').val("");
        $('#idTip').trigger("change");

        // Cambia a la Página
        $.mobile.changePage("#pageAbcUsuarios");
    });

    // Modificar Usuario
    $('#idModificar').click(function(e) 
    {
        // Verifica que haya un registro seleccionado
        if ($('#idIdeSelected').val()=="")
        {
            $('#idOperacion').html("Modificar");
            $( "#popupDialog").popup( "open" );
            setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);
        }
        else
        {
            // Deshabilita el Ide
            $('#idIde').prop( "disabled", true );
            
            // Coloca los datos a Modificar
            $('#idIde').val($('#idIdeSelected').val());
            $('#idCve').val($('#idCveSelected').val());
            $('#idNom').val($('#idNomSelected').val());
            $('#idResultado').html($('#idTipSelected').val());            
            $('#idTip').val($('#idTipSelected').val());
            $('#idTip').trigger("change");
            $('#idAC').html("Modificar");
            $('#idResultado').html("Ready");            
            $.mobile.changePage("#pageAbcUsuarios");                                     
        }
        
    });

    // Eliminar Usuario
    $('#idEliminar').click(function(e) 
    {
        // Verifica que haya un registro seleccionado
        if ($('#idIdeSelected').val()=="")
        {
            $('#idOperacion').html("Eliminar");
            $( "#popupDialog").popup( "open" );
            setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);   
        }
        else
        {
            // ajax para Eliminar los datos
            $.post("http://"+sHost+"/scm/www/php/ajaxUsuarioEli.php",
            {
                'UsuarioIde':$('#idIdeSelected').val()
            },
            function(data)
            {                
                // Valida si hubo error
                if (data.indexOf("Error")<0)                        
                {
                    // Carga de Nuevo la Ventana
                    //window.location.href="usuarios.html?"+$("#idUser").html();
                    fnCargaUsuarios();
                }
                else
                {
                    $('#idMensaje').html(data);
                    $( "#popupDialog").popup( "open" );
                }
                   
            })
            .fail(function() 
            {
                $('#idMensaje').html("Error Inesperado al Eliminar Usuario");
                $( "#popupDialog").popup( "open" );
            });
        }        
    });

    // Carga los Usuarios
    function fnCargaUsuarios()
    {
        // Carga los Usuarios al Cargar la Página
        $.post("http://"+sHost+"/scm/www/php/ajaxListarUsuarios.php", 
        function(data) 
        {            
            $('#tblUsuarios tbody tr').empty();
            for (var i=0; i<data.length; i++) 
            {
                $('#tblUsuarios tbody').append('<tr><td>'+ data[i].ide+'</td><td>'+ data[i].cve+'</td><td>'+data[i].nom+'</td><td>'+data[i].tip+'</td></tr>');
            }
        }, 
        "json")
        .fail(function() {
            alert("Error en la Carga de Usuarios");
        });  
    }
});

