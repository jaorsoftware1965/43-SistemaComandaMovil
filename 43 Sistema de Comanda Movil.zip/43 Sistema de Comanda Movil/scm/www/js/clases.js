$(document).ready(function()
{    
    // Carga los parámetros
    var paramstr = window.location.search.substr(1);
    
    // Obtiene la posición de los ":"
    var iPos2Puntos = paramstr.indexOf(":");

    // Obtiene el Usuario
    var sUser = paramstr.substr(0,iPos2Puntos);    
    $("#idUser").html(sUser);    
    $("#idUser2").html(sUser); 
    
    // Obtiene el Host
    var sHost = paramstr.substr(iPos2Puntos + 1);    
    $("#idHost").html(sHost); 

    // Carga las Clases al Cargar la Página
    fnCargaClases();
        
    // Captura el Evento Click sobre la Tabla
    $('#tblClases tbody').on( 'click', 'tr', function () 
    {       
        if ($(this).hasClass('trSelected') ) 
        {
            // Elimina la Clase del row
            $(this).removeClass('trSelected');
            
            // Borra el Ide Seleccionado
            $('#idNumSelected').val("");
        }
        else 
        {
            // Remueve los Seleccionados que haya
            $('tr.trSelected').removeClass('trSelected');// Para que solo sea uno
            // Añade la clase  Seleccionada
            $(this).addClass('trSelected');  
            // Coloca el Ide Seleccionado
            $('#idNumSelected').val($(this).find('td').eq(0).text());
            $('#idNomSelected').val($(this).find('td').eq(1).text());
            $('#idAtiSelected').val($(this).find('td').eq(2).text());            
        }
    } );    
    
    // Captura el evento Click para el Botón de Aceptar
    $('#idAceptar').click(function(e) 
    {

        // Variable para el Mensaje
        var sMensaje="";
                    
        if ($('#idNom').val()=="")
            sMensaje=sMensaje + " El Nombre ";

        if ($('#idAti').val()==null)
            sMensaje=sMensaje + " Quien atiende ";    
        
        // Valida si despliega el Mensaje
        if (sMensaje!="")
        {
            sMensaje="Debe capturar los siguiente datos:"+sMensaje.substring(0,sMensaje.length);
            $('#idResultado').html(sMensaje);            
        }
        else
        {                                    
            // Verifica si es inserción o modificacion
            if ($('#idAC').html()=="Insertar")
            {
                // Realiza la Inserción
                $.post("http://"+sHost+"/scm/www/php/ajaxClaseIns.php",
                {
                    'ClaseNom':$('#idNom').val(),
                    'ClaseAti':$('#idAti').val()
                },
                function(data)
                {
                    // Coloca los datos
                    $("#idResultado").html(data);     
                    if (data.indexOf("Error")<0)                        
                    {
                        //window.location.href="clases.html?"+$("#idUser").html();
                        fnCargaClases();
                        window.history.back();
                    }
                })
                .fail(function() {
                    $('#idResultado').html("Error al Inesperado al Insertar Clase");
                });                          
            }
            else
            {
                // Reliza la Modificación
                $.post("http://"+sHost+"/scm/www/php/ajaxClaseMod.php",
                {
                    'ClaseNum':$('#idNum').val(),
                    'ClaseNom':$('#idNom').val(),
                    'ClaseAti':$('#idAti').val()
                },
                function(data)
                {
                    // Coloca los datos
                    $("#idResultado").html(data);     
                    if (data.indexOf("Error")<0)                        
                    {
                        //window.location.href="clases.html?"+$("#idUser").html();
                        fnCargaClases();
                        window.history.back();
                    }
                })
                 .fail(function() {
                    $('#idResultado').html("Error Inesperado al Modificar Clase");
                });                  
            }
        }                       
    });

    $(document).on('pageshow', '#pageAbcClases', function()
    { 
            // Coloca el Foco en el Nombre
            $('#idNom').focus();
    });  
    
    // Insertar Clase
    $('#idInsertar').click(function(e) 
    {   
        // Habilita el Numero
        $('#idNum').prop( "disabled", true );                        
        $('#idAC').html('Insertar');
        $("#idResultado").html("Ready");    
        // Limpia el dato previo
        $('#idNum').val("Automático");
        $('#idNom').val("");
        $('#idAti').val("");
        $('#idAti').trigger("change");

        // Cambia a la Página de AC
        $.mobile.changePage("#pageAbcClases");
    });

    // Modificar Clase
    $('#idModificar').click(function(e) 
    {
        // Verifica que haya un registro seleccionado
        if ($('#idNumSelected').val()=="")
        {
            $('#idOperacion').html("Modificar");
            $( "#popupDialog").popup( "open" );
            setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);
        }
        else
        {            
            // Coloca los datos a Modificar
            $('#idNum').val($('#idNumSelected').val());
            $('#idNom').val($('#idNomSelected').val());
            $('#idAti').val($('#idAtiSelected').val());
            $('#idAti').trigger("change");
            $('#idAC').html("Modificar");
            $("#idResultado").html("Ready");
            $.mobile.changePage("#pageAbcClases");                                     
        }        
    });

    // Eliminar Clase
    $('#idEliminar').click(function(e) 
    {
        // Verifica que haya un registro seleccionado
        if ($('#idNumSelected').val()=="")
        {
            $('#idOperacion').html("Eliminar");
            $( "#popupDialog").popup( "open" );
            setTimeout(function(){  $("#popupDialog").popup("close"); }, 5000);   
        }
        else
        {
            // ajax para Eliminar los datos
            $.post("http://"+sHost+"/scm/www/php/ajaxClaseEli.php",
            {
                'ClaseNum':$('#idNumSelected').val()
            },
            function(data)
            {                
                // Valida si hubo error
                if (data.indexOf("Error")<0)                        
                {
                    // Carga de Nuevo la Ventana
                    //window.location.href="clases.html?"+$("#idUser").html();
                    fnCargaClases();
                }
                else
                {
                    $('#idMensaje').html(data);
                    $( "#popupDialog").popup( "open" );
                }
                   
            })
            .fail(function() 
            {
                $('#idMensaje').html("Error Inesperado al Eliminar Clase");
                $( "#popupDialog").popup( "open" );
            });
        }        
    });

    // Carga las Clases de Productos
    function fnCargaClases()
    {
        // Carga las Clases
        $.post("http://"+sHost+"/scm/www/php/ajaxListarClases.php", 
         function(data) 
         {
            $('#tblClases tbody tr').empty();
            for (var i=0; i<data.length; i++) 
            {
                //$('#tblClases tr:last').after('<tr><td>'+ data[i].num+'</td><td>'+data[i].nom+'</td><td>'+data[i].ati+'</td></tr>');
                $('#tblClases tbody').append('<tr><td>'+ data[i].num+'</td><td>'+data[i].nom+'</td><td>'+data[i].ati+'</td></tr>');
            }
         }, 
         "json")
         .fail(function() {
            alert("Error en la Carga de Clases");
        });          
    }
});

