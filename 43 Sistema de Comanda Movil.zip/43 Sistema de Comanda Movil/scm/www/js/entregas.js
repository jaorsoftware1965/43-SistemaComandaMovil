$(document).ready(function()
{    
    // Carga el Nombre al cargar la Página
    var sUser  = window.location.search.substr(1);
    $("#idUser").html(sUser);    
    
    
    // Carga los Productos a Entregar
    fnCargaEntregas();
        
    // Captura el Evento Click sobre la Tabla
    $('#tblEntregas tbody').on( 'click', 'tr', function () 
    {       
        // Obtiene los datos necesarios para actualizar
        var Servicio = $(this).find('td').eq(0).text();
        var Mesa     = $(this).find('td').eq(1).text();
        var Registro = $(this).find('td').eq(2).text();
        
        // Ejecuta ajax para actualizar la Comanda
        // Reliza la Modificación
        $.post("http://localhost/scm/php/ajaxComandaSta.php",
        {'ServicioNum':Servicio,
         'MesaNum':Mesa,
         'ProductoReg':Registro,
         'ProductoSta':"E"},
         function(data)
         {
            // Verifica que no haya habido error
            if (data.indexOf("Error")<0)                        
            {
                // Elimina y Carga de nuevo las Comandas a Entregar                
                $('#tblEntregas tbody tr').empty();
                fnCargaEntregas();
            }
         });
        
    });    
    
    
    // Carga los Productos a Entregar
    function fnCargaEntregas()
    {        
        // Carga los Productos a Preparar
        $.post("http://localhost/scm/php/ajaxListarEntregas.php", 
         {'MeseroIde':$("#idUser").html()},           
         function(data) 
         {
            // Ciclo para agregar
            for (var i=0; i<data.length; i++) 
            {
                $('#tblEntregas tr:last').after('<tr><td>'+ data[i].ser+'</td><td>'+data[i].mes+'</td><td>'+data[i].reg+'</td><td>'+data[i].pro+'</td><td>'+data[i].com+'</td></tr>');
            }
         }, 
         "json");
    }
});
