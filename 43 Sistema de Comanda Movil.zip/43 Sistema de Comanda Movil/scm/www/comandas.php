<!DOCTYPE html>
<html>
<head>
    <title>SCM - Comandas</title>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, minimum-scale=1, initial-scale=1, user-scalable=no">    
    <style>
        @-ms-viewport { width: 100vw ; min-zoom: 100% ; zoom: 100% ; }  @viewport { width: 100vw ; min-zoom: 100% zoom: 100% ; }
        @-ms-viewport { user-zoom: fixed ; min-zoom: 100% ; }           @viewport { user-zoom: fixed ; min-zoom: 100% ; }
    </style>

    <!-- Agrego las reglas css -->
    <link href="css/themes/default/jquery.mobile-1.4.5.min.css" rel="stylesheet">
    
    <!-- Agrego las reglas css -->
    <link href="css/comandas.css" rel="stylesheet">    
        
    <!-- Script de jQuery-->
    <script src="js/jquery.js"></script>
    
    <!-- Script de jQueryMobile-->
    <script src="js/jquery.mobile-1.4.5.js"></script>            

    <!-- Script de la App -->
    <script src="js/comandas.js"></script>
    
</head>

<body>

    
    <!-- Página Principal -->
    <div data-role="page" id="pageComandas">

        <!-- Encabezado --> 
        <div data-role="header">
            <a id="btnRegresar" class="ui-btn ui-icon-back ui-btn-icon-left" >Regresar</a>
            <h1>SCM 2017</h1>
            <a href="#" class="ui-btn ui-icon-user ui-btn-icon-left" id="idUser"></a>
        </div>        
       
        <!-- Página Principal -->
        <div data-role="main" class="ui-content">
            <h2>Comandas</h2>
            
            <!-- Inputs Ocultos para Insertar y Eliminar -->
            <input type="hidden" id="idCveSelected" >
            <input type="hidden" id="idDscSelected" >
            <input type="hidden" id="idPreSelected" >
            <input type="hidden" id="idClaSelected" >  

            <!--Mesas-->
            <label for="selMesas">Mesas:</label>
            <select id="selMesas">
            </select>
            
            <!--Clases-->
            <label for="idCla">Clase:</label>
            <select id="idCla">
            </select>
            
            <!--Productos-->
            <div id="divProductos">
           
                <!-- Tabla de Productos -->
                <table data-role="table" class="ui-responsive" id="tblProductos" >
                  <thead>
                    <tr>
                      <th width="20%">Cve</th>
                      <th width="40%">Dsc</th>                        
                      <th width="20%">Pre</th>
                      <th width="20%">Cla</th>
                    </tr>                  
                  </thead>
                  <tbody>                      
                  </tbody>
                </table>
            </div>
            <br>
            <!--Seleccionados-->
            <label for="idSeleccionados" id="lblSeleccionados">Seleccionados:</label>
            <div id="divSeleccionados">           
                <!-- Tabla de Productos Seleccionados -->
                <table data-role="table" class="ui-responsive" id="tblSeleccionados" >
                  <thead>
                    <tr>
                      <th width="20%">Cve</th>
                      <th width="40%">Dsc</th>                        
                      <th width="10%">Pre</th>
                      <th width="10%">Cla</th>
                      <th width="20%">Com</th>                          
                    </tr>                  
                  </thead>
                  <tbody>
                  </tbody>
                </table>
            </div>
            
           <!--Productos-->
        </div>                   
        <!-- Página Principal -->
        
        <!-- Pie de Página --> 
        <div data-role="footer" data-position="fixed">
            <!--  Productos --> 
            <a id="btnProductos" class="ui-corner-all ui-shadow ui-icon-forbidden ui-btn-icon-left">Productos: <span id="Productos">0</span></a>                   
                       
            <!-- Total -->            
            <a id="btnTotal" class="ui-btn ui-corner-all ui-shadow ui-icon-action ui-btn-icon-left ui-btn-right">Total: <span id="Total">0</span></a>
           
            <!-- Mensajes -->            
            <!--<div class="Mensajes" style="text-align:center">
                <strong>Mensaje: </strong><span id="idResultado">Ready</span>
            </div>-->
            
            <!-- Acciones a Realizar-->            
            <div data-role="navbar">
                <ul>
                  <li><a id="btnCancelar"  data-icon="forbidden">Cancelar</a></li>
                  <li><a id="btnGrabar"    data-icon="action"   >Grabar</a></li>
                  <li><a id="btnFinalizar" data-icon="refresh"  >Finalizar</a></li>
                </ul>
            </div>
           
       </div>
   
        <!-- Dialogo para Mensajes -->
        <div data-role="popup" id="popupDialog" data-overlay-theme="b" data-theme="b" 
             data-dismissible="false" style="max-width:400px;">
             <div data-role="header" data-theme="a">
                <h1>SCM 2017</h1>
             </div>
             <div role="main" class="ui-content">
                <h3 id="idMensaje" class="ui-title"></h3>
                <a href="#" class="ui-btn ui-corner-all ui-shadow ui-btn-inline ui-btn-b" data-rel="back">Aceptar</a>
             </div>
        </div>
        <!-- Dialogo para Mensajes -->
    
        <!-- Dialogo para Comentarios -->
        <div data-role="popup" id="popupComentario" data-overlay-theme="a" data-theme="a" 
             data-dismissible="false" style="max-width:400px;">
             <div data-role="header" data-theme="a">
                <h1>SCM 2017</h1>
             </div>
             <div role="main" class="ui-content" style="width:350px">
                 
                    <label for="selComentarios">Comentarios:</label>
                    <select id="selComentarios">
                    </select>                 
                 
                 <a class="ui-btn ui-corner-all ui-shadow ui-btn-inline ui-btn-a" data-rel="back" id="btnAceptarComentario">Aceptar</a>
             </div>
        </div>
        <!-- Dialogo para Mensajes -->
    

    </div>
    <!-- Página Principal -->
    
    
</body>
</html>

