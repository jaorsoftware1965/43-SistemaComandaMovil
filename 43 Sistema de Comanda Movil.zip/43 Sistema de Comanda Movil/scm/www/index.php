<!DOCTYPE html>
<html>
<head data-noxhrfix>

    <title>SCM - Acceso</title>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, minimum-scale=1, initial-scale=1, user-scalable=no">
    
    <style>
        @-ms-viewport { width: 100vw ; min-zoom: 100% ; zoom: 100% ; }  @viewport { width: 100vw ; min-zoom: 100% zoom: 100% ; }
        @-ms-viewport { user-zoom: fixed ; min-zoom: 100% ; }           @viewport { user-zoom: fixed ; min-zoom: 100% ; }
    </style>

    
    <!-- Agrego las reglas css de la app -->
    <link href="css/index.css?<?php echo time()?>" rel="stylesheet">
    
    <!-- Agrego las reglas css de jquerymobile-->
    <link href="css/themes/default/jquery.mobile-1.4.5.min.css" rel="stylesheet">
        
    <!-- Script de jQuery-->
    <script src="js/jquery.js"></script>
    
    <!-- Script de jQueryMobile-->
    <script src="js/jquery.mobile-1.4.5.js"></script>            

    <!-- Script de la App -->
    <script src="js/index.js?<?php echo time()?>"></script>

   

</head>

<body>

    <!-- Página Principal -->
    <div data-role="page">

       <!-- Encabezado --> 
       <div data-role="header">
         <h1>JSComandas M2017</h1>
       </div>

       <!-- Contenido Principal -->    
       <div data-role="main" class="ui-content">
            
            <!-- Forma de Sesión -->    
            <form name="sesion" method="post" action="">
            
                <h2>Acceso</h2>
                
                <!-- Host -->    
                <label for="idHost">Host:</label>
                <input type="text" name="nameHost" id="idHost" data-clear-btn="true" value="localhost" required>
                
                <!-- Usuario -->    
                <label for="idUsuario">Usuario:</label>
                <input type="text" name="nameUsuario" id="idUsuario" data-clear-btn="true" value="sa" required>

                <!-- Clave -->    
                <label for="idClave">Clave:</label>
                <input type="password" name="nameClave" id="idClave" data-clear-btn="true" value="admin" required>
                
                <div class="Mensajes">
                    <strong>Mensaje: </strong><span id="idResultado">Ready</span>
                </div>

                <!-- Botón de Submit -->    
                <input type="submit" value="Aceptar">
                           
            </form>
            <!-- Forma de Sesión -->
           
       </div>

       <!-- Pie de Página --> 
       <div data-role="footer" data-position="fixed">
         <h1>Capture Host, Usuario y Clave para Acceder</h1>
       </div>

    </div>
    <!-- Página Principal -->

</body>
</html>
