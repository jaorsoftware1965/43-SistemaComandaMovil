<!DOCTYPE html>
<html>
<head>
    <title>SCM - Ventas</title>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, minimum-scale=1, initial-scale=1, user-scalable=no">    
    <style>
        @-ms-viewport { width: 100vw ; min-zoom: 100% ; zoom: 100% ; }  @viewport { width: 100vw ; min-zoom: 100% zoom: 100% ; }
        @-ms-viewport { user-zoom: fixed ; min-zoom: 100% ; }           @viewport { user-zoom: fixed ; min-zoom: 100% ; }
    </style>

    <!-- Agrego las reglas css -->
    <link href="css/ventas.css" rel="stylesheet">
    
    <!-- Agrego las reglas css -->
    <link href="css/themes/default/jquery.mobile-1.4.5.min.css" rel="stylesheet">
            
    <!-- Script de jQuery-->
    <script src="js/jquery.js"></script>
    
    <!-- Script de jQueryMobile-->
    <script src="js/jquery.mobile-1.4.5.js"></script>            

    <!-- Script de la App -->
    <script src="js/ventas.js"></script>
    
</head>

<body>

    
    <!-- Página Principal -->
    <div data-role="page" id="pageVentas">

       <!-- Encabezado --> 
       <div data-role="header">
           <a data-rel="back" class="ui-btn ui-icon-home ui-btn-icon-left" >Home</a>
           <h1>SCM 2017</h1>
           <a href="#" class="ui-btn ui-icon-user ui-btn-icon-left" id="idUser"></a>
       </div>        
       
       <!-- Página Principal -->
       <div data-role="main" class="ui-content">
            <h2>Ventas</h2>
            <input type="text" id="idTotal" readonly>
            <label for="selMeseros">Filtre Consulta por Mesero</label>
            <select id="selMeseros">
                <option value="0" selected>Seleccione</option>
                <option value="">Todos</option>
            </select>
           
            <label for="selProductos">Filtre Consulta por Producto</label>
            <select id="selProductos">
                <option value="0" selected>Seleccione</option>
                <option value="">Todos</option>
            </select>
            
            <!-- Tabla de Ventas -->
            <table data-role="table" class="ui-responsive" id="tblVentas" >
              <thead>
                <tr>                    
                    <th width="10%">Num</th>
                    <th width="30%">Fecha</th>
                    <th width="10%">Mesa</th>
                    <th width="10%">Mesero</th>
                    <th width="20%">Comensales</th>                    
                    <th width="20%">Total</th>
                </tr>                  
              </thead>
              <tbody>                  
              </tbody>
            </table>
       </div>                    
        
       <!-- Pie de Página --> 
       <div data-role="footer" data-position="fixed">
         <h1>Seleccione el Filtro</h1>           
       </div>        
                
    </div>
    <!-- Página Principal -->
            
</body>
</html>