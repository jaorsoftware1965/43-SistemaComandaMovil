<!DOCTYPE html>
<html>
<head>
    <title>SCM - Principal</title>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, minimum-scale=1, initial-scale=1, user-scalable=no">    
    <style>
        @-ms-viewport { width: 100vw ; min-zoom: 100% ; zoom: 100% ; }  @viewport { width: 100vw ; min-zoom: 100% zoom: 100% ; }
        @-ms-viewport { user-zoom: fixed ; min-zoom: 100% ; }           @viewport { user-zoom: fixed ; min-zoom: 100% ; }
    </style>

    <!-- Agrego las reglas css -->
    <link href="css/servicios.css" rel="stylesheet">
    
    <!-- Agrego las reglas css -->
    <link href="css/themes/default/jquery.mobile-1.4.5.min.css" rel="stylesheet">
        
    <!-- Script de jQuery-->
    <script src="js/jquery.js"></script>

    <!-- Script de la App -->
    <script src="js/servicios.js"></script>

    <!-- Script de jQueryMobile-->
    <script src="js/jquery.mobile-1.4.5.js"></script>                

</head>

<body>

    <!-- Página Principal -->
    <div data-role="page" id="pageIniciar">

       <!-- Encabezado --> 
       <div data-role="header">
           <a data-rel="back" class="ui-btn ui-icon-home ui-btn-icon-left" >Home</a>
           <h1>SCM 2017</h1>
           <a href="#" class="ui-btn ui-icon-user ui-btn-icon-left" id="idUser"></a>
       </div>        
       <!-- Contenido Principal --> 
       <div data-role="main" class="ui-content">        
            <h2>Iniciar Servicio</h2>
           
            <label for="idMesas">Mesas Disponibles:</label>
            <select id="idMesas">
            </select>
           
            <label for="idComensales">Comensales:</label>
            <select id="idComensales">
            </select>
            
            <center>
                <img src="imagenes/mesa_comensales.jpg">
                <div class="Mensajes">
                     <strong>Mensaje: </strong><span id="idResultado"></span>
                </div>
                <button id="idAceptar">Aceptar</button>
            </center>
            
        </div>
                    
       <!-- Pie de Página --> 
       <div data-role="footer" data-position="fixed">
         <h1>Seleccione Mesa y Comensales</h1>
       </div>

    </div>
    <!-- Página Principal -->    
    
</body>
</html>
